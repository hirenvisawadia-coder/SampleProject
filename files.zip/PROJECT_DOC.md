# Smart Backlog Assistant — Project Documentation

This document covers the five required steps from the brief: problem
definition, solution design, testing approach, implementation notes, and
reflection.

---

## 1. Problem definition

Engineering teams generate requirements in the messiest possible formats —
rambling sprint-planning transcripts, half-finished requirement docs, Slack
recaps. Someone (usually a PM or tech lead) then spends 1–2 hours per meeting
manually converting that into tracker-ready tickets. Two things reliably go
wrong: **items get lost** (the throwaway "FYI the cert renewal is manual"
comment that later causes downtime), and **duplicates get created** because
nobody cross-checked the existing backlog.

### Use cases

1. **Sprint-planning digestion.** A tech lead pastes raw multi-speaker meeting
   notes and gets back prioritized, tracker-ready user stories with acceptance
   criteria — in minutes instead of an hour.
2. **Requirements-doc breakdown.** A PM feeds a draft requirements document
   and gets it decomposed into individually deliverable stories, with the
   doc's own "out of scope" and "open items" sections respected.
3. **Duplicate prevention.** Before creating tickets, the tool compares new
   items against the existing backlog JSON and flags likely duplicates
   ("Apple Pay came up again — that's BL-201, don't re-create it").

### AI used in problem refinement

I used Claude conversationally to stress-test the problem statement. The most
useful pushback: my first framing ("summarize meeting notes") was too broad —
summaries aren't actionable. Reframing the output as *tracker-ready user
stories with testable acceptance criteria* gave the project a concrete,
verifiable definition of done.

---

## 2. Solution design

### Architecture

```
┌──────────────────┐     ┌──────────────────┐
│  Meeting notes    │     │  backlog.json     │
│  .txt/.md/.pdf    │     │  (optional)       │
└────────┬─────────┘     └────────┬─────────┘
         │ load_document()        │ load_backlog()
         │ (validate, truncate)   │ (validate, slim fields)
         ▼                        ▼
     ┌────────────────────────────────┐
     │        Prompt builder           │  prompts.py
     │  system prompt + XML-tagged     │
     │  inputs + schema + few-shot     │
     └───────────────┬────────────────┘
                     ▼
     ┌────────────────────────────────┐
     │      Anthropic API  ★ AI ★     │  claude-sonnet-4-5
     │  retries + exponential backoff  │
     └───────────────┬────────────────┘
                     ▼
     ┌────────────────────────────────┐
     │   Parse & validate response     │
     │  strip fences → json.loads →    │
     │  normalize enums (P-levels,     │
     │  categories) with warnings      │
     └───────┬───────────────┬────────┘
             ▼               ▼
      output/report.md   output/stories.json
      (human review)     (tracker import)
```

AI is used at exactly one point — the extraction/structuring step — because
that's the only step that requires judgment. Loading, validation, parsing,
and rendering are deterministic code, which keeps failures debuggable.

### Prompt design approach

All prompts live in `prompts.py` with inline annotations. Six techniques:

| Technique | Why |
|---|---|
| Role prompting ("senior agile coach") | Raised the baseline quality of story phrasing and rationale |
| Strict output contract (JSON-only, exact schema, enums) | Makes output machine-parseable; enums (P0–P3, fixed categories) prevent priority-vocabulary drift |
| One few-shot example | Fixed the two worst failure modes: vague acceptance criteria ("works correctly") and missing rationale |
| XML-tagged inputs | Cleanly separates notes from backlog so backlog titles aren't mistaken for new requirements |
| Negative instructions | "Do NOT invent requirements", "one story = one deliverable" — both were observed failure modes before adding them |
| Escape hatch (`open_questions`) | Gives the model a legitimate place to put ambiguity instead of hallucinating scope |

### AI assistance in design

I used Claude to (a) draft the initial JSON schema, then trimmed fields I
couldn't justify (e.g. a `story_points` estimate — the model has no basis for
estimating a team's velocity, so including it would be confident nonsense),
and (b) generate the deliberately-messy sample inputs, which I then edited to
plant specific traps (backlog overlaps, an out-of-scope section, a no-spec
request).

---

## 3. Testing approach

### Sample inputs and "good output" definitions

**Scenario 1 — `meeting_notes_sprint_planning.txt`** (messy multi-speaker notes)
Good output means:
- 4–5 stories: decline reasons, VoiceOver/accessibility, Safari coupon bug,
  Apple Pay spike; Node 16 upgrade either a story or duplicate-flagged
- Accessibility item is P0/P1 (legal exposure, "non-negotiable" in notes)
- Apple Pay flagged against BL-201 and categorized `research` (it's a spike)
- Node 16 flagged against BL-202
- The unresolved 3DS question appears in `open_questions`, not as invented
  acceptance criteria

**Scenario 2 — `requirements_notifications.md`** (semi-formal doc)
Good output means:
- Stories for: per-category toggles, one-click signed link, delivery-latency
  infra work, audit log
- The "security notifications cannot be disabled" compliance rule appears as
  an acceptance criterion, not a separate story
- SMS/push and frequency controls (explicit out-of-scope) produce **zero** stories
- Link expiry and migration defaults land in `open_questions`

**Scenario 3 — `meeting_notes_vague.txt`** (underspecified edge case)
Good output means:
- "Dashboard slow" becomes a *research/profiling* story, not a performance fix
  with invented numbers
- Flaky test → tech-debt; cert renewal → infra with high priority (past
  downtime), duplicate-flagged against BL-205
- "Something with AI on the landing page" produces an open question, **not** a
  story — there is no requirement to extract

### Verification method

1. **Manual review against the definitions above.** For each run I checked
   every story against its scenario's checklist, plus three global checks:
   every story traceable to a sentence in the notes (no hallucinated scope);
   every acceptance criterion answerable yes/no by a QA engineer; priorities
   defensible from the notes' own language.
2. **Offline pipeline tests** (`test_pipeline_offline.py`) cover the
   deterministic half without an API key: fenced-JSON stripping, malformed
   response handling, enum normalization (priority "High" → P2 + warning),
   string-vs-list acceptance criteria, and Markdown rendering.
3. **Error-path testing:** missing file, empty file, invalid backlog JSON,
   missing API key — each produces a specific, actionable error message and
   exit code 1 rather than a stack trace.

---

## 4. Implementation notes

Key decisions (also marked `# DECISION:` in code):

- **Normalize, don't reject.** Model output that's *slightly* off-schema
  (priority "high" instead of "P1") is salvaged with a logged warning.
  Failing an entire run over a fixable enum is bad UX.
- **Always save the raw response** to `last_raw_response.txt` before parsing.
  When parsing fails, this is the difference between a 30-second fix and
  blind re-running.
- **Defensive JSON extraction.** Even with "JSON only" instructions, fenced
  or preambled output happens; strip fences, then regex the outermost object
  as a fallback.
- **Retry only what's retryable.** Rate limits and connection errors get
  exponential backoff; authentication errors fail immediately with a
  pointed message.
- **Input truncation at 50k chars** so a huge PDF can't blow the context
  window or the bill.
- **Slim the backlog before sending** — only id/title/status/priority go to
  the model. Less noise, fewer tokens, no accidental leakage of ticket
  descriptions that might contain sensitive detail.

### How AI was used during development

- Drafted the first version of the extraction prompt, then iterated (history below)
- Generated realistic sample inputs which I edited to plant test traps
- Rubber-ducked the error-handling strategy (retryable vs non-retryable errors)
- Reviewed the parsing code for edge cases I'd missed (the "acceptance
  criteria returned as a single string" case came from that review)

### Prompt iteration history (abridged)

| Version | Problem observed | Fix |
|---|---|---|
| v1: "extract user stories from these notes as JSON" | Vague criteria ("feature works well"), merged unrelated asks, invented a mobile app requirement | Added negative instructions + one-story-one-deliverable rule |
| v2: + rules | Priorities came back as "High/Medium/Low" and drifted between runs | Enum contract (P0–P3) + rationale field to force justification |
| v3: + enums | Still occasionally guessed answers to open questions in the notes | Added `open_questions` escape hatch + "do not invent" rule |
| v4: + few-shot example | — | Final: example anchored criteria specificity and rationale quality |

---

## 5. Reflection

**What worked well**
- The `open_questions` escape hatch was the single highest-leverage prompt
  change — it converted the hallucination failure mode into a feature (the
  tool now surfaces what the *team* needs to decide).
- Separating prompts into their own annotated module made iteration fast and
  makes the prompt engineering reviewable, which this brief asks for.
- Duplicate detection via a slimmed backlog worked better than expected;
  the model reliably matched "Apple Pay again" to BL-201.

**What I'd improve with more time**
- **Structured outputs / tool use:** use the API's tool-calling with a JSON
  schema instead of prompt-enforced JSON — stronger guarantee, less defensive
  parsing.
- **Automated eval harness:** the "good output" checklists in §3 are manual;
  they could become assertions (e.g. "scenario 2 must yield 0 stories
  mentioning SMS") run against N samples to measure consistency.
- **Real tracker integration:** `stories.json` is designed for import; a
  Jira/Linear API push would close the loop.
- **Chunking for long inputs** instead of truncation, with a merge pass.
