# Smart Backlog Assistant

Turns raw meeting notes or requirement documents into structured, prioritized
user stories with acceptance criteria — and checks your existing backlog to
flag likely duplicates.

Built with the Anthropic API. ~350 lines of Python, no framework.

## What it does

```
notes.txt / .md / .pdf ─┐
                        ├─► [prompt builder] ─► Claude API ─► JSON parse/validate ─► report.md + stories.json
backlog.json (optional)─┘
```

For each requirement found in the notes it generates:
- a user story in `As a <role>, I want <goal>, so that <benefit>` form
- testable acceptance criteria
- a priority (P0–P3) and category (feature / bug / tech-debt / research / infra / ux) with rationale
- links to related existing backlog items, and a duplicate warning where appropriate
- plus an overall requirements summary and a list of open questions the model
  couldn't resolve from the notes (instead of inventing answers)

## Setup

Requires Python 3.10+.

```bash
pip install anthropic
pip install pypdf              # optional, only needed for PDF inputs

export ANTHROPIC_API_KEY=sk-ant-...
```

## Usage

```bash
python backlog_assistant.py sample_inputs/meeting_notes_sprint_planning.txt \
    --backlog sample_inputs/backlog.json \
    --out output/
```

Outputs:
- `output/report.md` — human-readable report, stories sorted by priority
- `output/stories.json` — machine-readable, ready for tracker import
- `output/last_raw_response.txt` — raw model output, kept for debugging

Run without a backlog (duplicate detection is simply skipped):

```bash
python backlog_assistant.py sample_inputs/requirements_notifications.md
```

## Testing without an API key

The parsing, validation, and rendering pipeline can be exercised offline:

```bash
python test_pipeline_offline.py
```

This feeds a canned model response (including a deliberately malformed one)
through `parse_response` → `UserStory.from_dict` → `render_markdown` and
asserts the normalization behaves (bad priority → P2 with a warning, fenced
JSON stripped, etc.).

## Project structure

```
backlog_assistant.py       main pipeline (load → prompt → API → parse → render)
prompts.py                 all prompt engineering, annotated
test_pipeline_offline.py   offline tests for parsing/validation/rendering
sample_inputs/             3 realistic scenarios + a sample backlog
PROJECT_DOC.md             problem definition, design, testing, reflection
```

## Sample scenarios included

| Input | What it exercises |
|---|---|
| `meeting_notes_sprint_planning.txt` | Messy multi-speaker notes; mixed priorities; two items that overlap with the existing backlog (Apple Pay, Node 16) — should be flagged as duplicates, not re-created |
| `requirements_notifications.md` | Semi-formal doc with explicit out-of-scope section and unresolved open items — those should land in `open_questions`, not become stories |
| `meeting_notes_vague.txt` | Deliberately vague/underspecified notes ("something with AI, no spec") — tests that the model asks questions instead of inventing scope |

See `PROJECT_DOC.md` for the design rationale, prompt iteration history, and
what "good output" was defined as for each scenario.
