#!/usr/bin/env python3
"""
Smart Backlog Assistant
=======================
An AI-assisted CLI tool that turns raw meeting notes or requirement
documents into structured, prioritized user stories -- while checking
the existing backlog to avoid duplicates and suggest related items.

Pipeline:
    1. Load input document (.txt / .md / .pdf)
    2. Load existing backlog (JSON)
    3. Build a structured prompt (see prompts.py)
    4. Call the Anthropic API (with retries + error handling)
    5. Parse & validate the JSON response
    6. Render Markdown report + machine-readable JSON output

Usage:
    export ANTHROPIC_API_KEY=sk-ant-...
    python backlog_assistant.py sample_inputs/meeting_notes_sprint_planning.txt \
        --backlog sample_inputs/backlog.json \
        --out output/

Design decisions worth noting are marked with "# DECISION:" comments.
"""

import argparse
import json
import logging
import os
import re
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path

from prompts import SYSTEM_PROMPT, build_user_prompt

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

MODEL = "claude-sonnet-4-5"      # DECISION: Sonnet balances quality/cost for
                                 # structured extraction; Haiku was too lossy
                                 # on acceptance criteria in early testing.
MAX_TOKENS = 4000
MAX_RETRIES = 3
RETRY_BASE_DELAY = 2.0           # seconds; doubles each retry (exponential backoff)

VALID_PRIORITIES = {"P0", "P1", "P2", "P3"}
VALID_CATEGORIES = {"feature", "bug", "tech-debt", "research", "infra", "ux"}

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-7s  %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("backlog-assistant")


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------

@dataclass
class UserStory:
    """One generated user story. Mirrors the JSON schema we ask Claude for."""
    title: str
    story: str                       # "As a <role>, I want <goal>, so that <benefit>"
    acceptance_criteria: list[str]
    priority: str                    # P0..P3
    category: str                    # feature / bug / tech-debt / ...
    rationale: str                   # why this priority/category
    related_backlog_ids: list[str] = field(default_factory=list)
    possible_duplicate_of: str | None = None

    @classmethod
    def from_dict(cls, d: dict) -> "UserStory":
        """Build a story from Claude's JSON, normalizing anything off-schema.

        DECISION: We normalize instead of rejecting. LLM output is mostly
        right but occasionally drifts (e.g. priority "High" instead of "P1").
        Salvaging with a warning beats failing the whole run.
        """
        priority = str(d.get("priority", "P2")).strip().upper()
        if priority not in VALID_PRIORITIES:
            log.warning("Non-standard priority %r -> defaulting to P2", priority)
            priority = "P2"

        category = str(d.get("category", "feature")).strip().lower()
        if category not in VALID_CATEGORIES:
            log.warning("Non-standard category %r -> defaulting to 'feature'", category)
            category = "feature"

        criteria = d.get("acceptance_criteria") or []
        if isinstance(criteria, str):          # sometimes returned as one string
            criteria = [c.strip("-• ").strip() for c in criteria.splitlines() if c.strip()]

        return cls(
            title=str(d.get("title", "Untitled story")).strip(),
            story=str(d.get("story", "")).strip(),
            acceptance_criteria=[str(c).strip() for c in criteria],
            priority=priority,
            category=category,
            rationale=str(d.get("rationale", "")).strip(),
            related_backlog_ids=[str(i) for i in d.get("related_backlog_ids", [])],
            possible_duplicate_of=d.get("possible_duplicate_of") or None,
        )


# ---------------------------------------------------------------------------
# Input loading
# ---------------------------------------------------------------------------

def load_document(path: Path) -> str:
    """Load meeting notes / requirements from .txt, .md, or .pdf."""
    if not path.exists():
        raise FileNotFoundError(f"Input document not found: {path}")

    suffix = path.suffix.lower()
    if suffix in {".txt", ".md"}:
        text = path.read_text(encoding="utf-8", errors="replace")
    elif suffix == ".pdf":
        text = _extract_pdf_text(path)
    else:
        raise ValueError(f"Unsupported file type '{suffix}'. Use .txt, .md, or .pdf")

    text = text.strip()
    if not text:
        raise ValueError(f"Document {path} is empty -- nothing to analyze.")
    if len(text) < 40:
        log.warning("Document is very short (%d chars); results may be thin.", len(text))

    # DECISION: hard cap input size so a giant PDF can't blow the context
    # window or the API bill. 50k chars ~ 12k tokens, plenty for meeting notes.
    MAX_CHARS = 50_000
    if len(text) > MAX_CHARS:
        log.warning("Document truncated from %d to %d chars.", len(text), MAX_CHARS)
        text = text[:MAX_CHARS]

    log.info("Loaded document: %s (%d chars)", path.name, len(text))
    return text


def _extract_pdf_text(path: Path) -> str:
    """Extract text from a PDF. pypdf is an optional dependency."""
    try:
        from pypdf import PdfReader
    except ImportError as exc:
        raise RuntimeError(
            "PDF support requires pypdf. Install it with: pip install pypdf"
        ) from exc
    reader = PdfReader(str(path))
    return "\n".join((page.extract_text() or "") for page in reader.pages)


def load_backlog(path: Path | None) -> list[dict]:
    """Load the existing backlog JSON. Optional -- tool works without one."""
    if path is None:
        log.info("No backlog file supplied; duplicate detection disabled.")
        return []
    if not path.exists():
        raise FileNotFoundError(f"Backlog file not found: {path}")

    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ValueError(f"Backlog file {path} is not valid JSON: {exc}") from exc

    items = data.get("items", data) if isinstance(data, dict) else data
    if not isinstance(items, list):
        raise ValueError("Backlog JSON must be a list of items or {'items': [...]}")

    # Keep only the fields the model needs -- less noise, fewer tokens.
    slim = []
    for item in items:
        if not isinstance(item, dict):
            continue
        slim.append({
            "id": str(item.get("id", "?")),
            "title": str(item.get("title", "")),
            "status": str(item.get("status", "unknown")),
            "priority": str(item.get("priority", "")),
        })
    log.info("Loaded backlog: %d existing items", len(slim))
    return slim


# ---------------------------------------------------------------------------
# AI integration
# ---------------------------------------------------------------------------

def call_claude(document_text: str, backlog_items: list[dict]) -> str:
    """Call the Anthropic API with retries and clear error messages."""
    try:
        import anthropic
    except ImportError as exc:
        raise RuntimeError(
            "The 'anthropic' package is required. Install with: pip install anthropic"
        ) from exc

    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        raise RuntimeError(
            "ANTHROPIC_API_KEY is not set. Export it first:\n"
            "  export ANTHROPIC_API_KEY=sk-ant-..."
        )

    client = anthropic.Anthropic(api_key=api_key)
    user_prompt = build_user_prompt(document_text, backlog_items)

    last_error: Exception | None = None
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            log.info("Calling Anthropic API (model=%s, attempt %d/%d)...",
                     MODEL, attempt, MAX_RETRIES)
            t0 = time.time()
            response = client.messages.create(
                model=MODEL,
                max_tokens=MAX_TOKENS,
                system=SYSTEM_PROMPT,
                messages=[{"role": "user", "content": user_prompt}],
            )
            elapsed = time.time() - t0
            text = "".join(
                block.text for block in response.content if block.type == "text"
            )
            log.info("API call succeeded in %.1fs (%d output tokens)",
                     elapsed, response.usage.output_tokens)
            return text
        except anthropic.AuthenticationError:
            # No point retrying a bad key.
            raise RuntimeError("Authentication failed -- check your ANTHROPIC_API_KEY.")
        except (anthropic.RateLimitError, anthropic.APIStatusError,
                anthropic.APIConnectionError) as exc:
            last_error = exc
            if attempt < MAX_RETRIES:
                delay = RETRY_BASE_DELAY * (2 ** (attempt - 1))
                log.warning("API error (%s). Retrying in %.0fs...",
                            type(exc).__name__, delay)
                time.sleep(delay)

    raise RuntimeError(f"API call failed after {MAX_RETRIES} attempts: {last_error}")


def parse_response(raw: str) -> dict:
    """Parse Claude's response into a dict, tolerating markdown fences.

    DECISION: even with a "JSON only" instruction, models occasionally wrap
    output in ```json fences or add a preamble. We strip defensively and,
    as a last resort, regex out the outermost JSON object.
    """
    cleaned = raw.strip()
    cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned)
    cleaned = re.sub(r"\s*```$", "", cleaned)

    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        match = re.search(r"\{.*\}", cleaned, re.DOTALL)
        if match:
            try:
                return json.loads(match.group(0))
            except json.JSONDecodeError:
                pass
    raise ValueError(
        "Could not parse the model response as JSON. Raw response saved to "
        "output/last_raw_response.txt for debugging."
    )


# ---------------------------------------------------------------------------
# Output rendering
# ---------------------------------------------------------------------------

def render_markdown(result: dict, stories: list[UserStory], source_name: str) -> str:
    """Render a human-readable Markdown report."""
    lines = [
        f"# Backlog Assistant Report",
        f"",
        f"**Source:** `{source_name}`  ",
        f"**Generated stories:** {len(stories)}",
        f"",
        f"## Summary of key requirements",
        f"",
        result.get("summary", "_No summary produced._"),
        f"",
    ]

    open_questions = result.get("open_questions") or []
    if open_questions:
        lines += ["## Open questions for the team", ""]
        lines += [f"- {q}" for q in open_questions]
        lines += [""]

    lines += ["## Generated user stories", ""]
    # Sort P0 first -- reviewers read top-down.
    order = {"P0": 0, "P1": 1, "P2": 2, "P3": 3}
    for i, s in enumerate(sorted(stories, key=lambda s: order[s.priority]), 1):
        lines += [
            f"### {i}. {s.title}",
            f"",
            f"**Priority:** {s.priority} | **Category:** {s.category}",
            f"",
            f"> {s.story}",
            f"",
            f"**Acceptance criteria:**",
        ]
        lines += [f"- [ ] {c}" for c in s.acceptance_criteria]
        lines += ["", f"**Rationale:** {s.rationale}", ""]
        if s.possible_duplicate_of:
            lines += [f"⚠️ **Possible duplicate of backlog item `{s.possible_duplicate_of}`** -- review before creating.", ""]
        if s.related_backlog_ids:
            lines += [f"Related backlog items: {', '.join(f'`{i}`' for i in s.related_backlog_ids)}", ""]
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Turn meeting notes into structured, prioritized user stories."
    )
    parser.add_argument("document", type=Path,
                        help="Meeting notes / requirements (.txt, .md, or .pdf)")
    parser.add_argument("--backlog", type=Path, default=None,
                        help="Existing backlog JSON for duplicate detection")
    parser.add_argument("--out", type=Path, default=Path("output"),
                        help="Output directory (default: ./output)")
    args = parser.parse_args(argv)

    try:
        args.out.mkdir(parents=True, exist_ok=True)

        document_text = load_document(args.document)
        backlog_items = load_backlog(args.backlog)

        raw = call_claude(document_text, backlog_items)
        # Always save the raw response -- invaluable when parsing fails.
        (args.out / "last_raw_response.txt").write_text(raw, encoding="utf-8")

        result = parse_response(raw)
        stories = [UserStory.from_dict(d) for d in result.get("stories", [])]
        if not stories:
            log.warning("Model returned zero stories. Check the input document.")

        # Machine-readable output (e.g. for import into a tracker later)
        json_path = args.out / "stories.json"
        json_path.write_text(
            json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8"
        )

        # Human-readable report
        md_path = args.out / "report.md"
        md_path.write_text(
            render_markdown(result, stories, args.document.name), encoding="utf-8"
        )

        log.info("Done. %d stories written to:", len(stories))
        log.info("  %s  (Markdown report)", md_path)
        log.info("  %s  (JSON for tooling)", json_path)
        dupes = [s for s in stories if s.possible_duplicate_of]
        if dupes:
            log.info("  %d possible duplicate(s) flagged -- see report.", len(dupes))
        return 0

    except (FileNotFoundError, ValueError, RuntimeError) as exc:
        log.error("%s", exc)
        return 1


if __name__ == "__main__":
    sys.exit(main())
