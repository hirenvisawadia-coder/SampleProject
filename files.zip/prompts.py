"""
Prompt design for the Smart Backlog Assistant.

Prompts live in their own module so they can be reviewed, versioned, and
iterated on without touching pipeline code. See PROJECT_DOC.md for the
iteration history and why each technique below was chosen.

Techniques used (each is annotated inline):
  1. Role prompting            - senior agile coach persona
  2. Strict output contract    - JSON-only, exact schema, enum values
  3. Few-shot example          - one worked example anchors format & quality
  4. XML-tagged inputs         - unambiguous separation of notes vs backlog
  5. Negative instructions     - what NOT to do (invent scope, merge unrelated asks)
  6. Escape hatch              - open_questions field so ambiguity is surfaced,
                                 not papered over with invented requirements
"""

import json

# --- Technique 1 & 2: role + output contract ------------------------------
SYSTEM_PROMPT = """You are a senior agile coach and product analyst. You turn \
raw engineering meeting notes into well-formed user stories.

Rules:
- Respond with a single JSON object and NOTHING else: no preamble, no markdown fences.
- Every story must follow the "As a <role>, I want <goal>, so that <benefit>" format.
- Acceptance criteria must be concrete and testable (a QA engineer could verify each one).
- Priorities: P0 (blocking/urgent), P1 (this sprint), P2 (soon), P3 (nice to have).
- Categories: feature, bug, tech-debt, research, infra, ux.
- Do NOT invent requirements that are not supported by the notes. If something \
is ambiguous, put a question in "open_questions" instead of guessing.
- Do NOT merge unrelated requests into one story; one story = one deliverable.
- If a note clearly matches an existing backlog item, set "possible_duplicate_of" \
to that item's id rather than duplicating it."""


# --- Technique 3: few-shot example -----------------------------------------
# One compact worked example. In testing, this single example fixed two failure
# modes: vague acceptance criteria ("works correctly") and missing rationale.
FEW_SHOT_EXAMPLE = {
    "summary": "The team needs password reset via email because support tickets "
               "about locked accounts are the #1 ticket category.",
    "open_questions": [
        "Should reset links expire after 1 hour or 24 hours? Notes mention both."
    ],
    "stories": [
        {
            "title": "Self-service password reset via email",
            "story": "As a locked-out user, I want to reset my password via an "
                     "emailed link, so that I can regain access without contacting support.",
            "acceptance_criteria": [
                "A 'Forgot password?' link is visible on the login page",
                "Submitting a registered email sends a single-use reset link",
                "Submitting an unregistered email shows the same confirmation message (no account enumeration)",
                "Expired or already-used links show a clear error and offer to resend",
            ],
            "priority": "P1",
            "category": "feature",
            "rationale": "Directly reduces the top support ticket category; "
                         "explicitly requested for next sprint in the notes.",
            "related_backlog_ids": ["BL-104"],
            "possible_duplicate_of": None,
        }
    ],
}

OUTPUT_SCHEMA_DESCRIPTION = """{
  "summary": "2-4 sentence summary of the key requirements identified",
  "open_questions": ["question the team should answer", ...],
  "stories": [
    {
      "title": "short imperative title",
      "story": "As a <role>, I want <goal>, so that <benefit>",
      "acceptance_criteria": ["testable criterion", ...],
      "priority": "P0|P1|P2|P3",
      "category": "feature|bug|tech-debt|research|infra|ux",
      "rationale": "1-2 sentences: why this priority and category",
      "related_backlog_ids": ["ids of related existing items"],
      "possible_duplicate_of": "existing item id, or null"
    }
  ]
}"""


def build_user_prompt(document_text: str, backlog_items: list[dict]) -> str:
    """Assemble the user prompt with XML-tagged sections (technique 4)."""
    backlog_block = (
        json.dumps(backlog_items, indent=2)
        if backlog_items
        else "(no existing backlog provided -- skip duplicate detection)"
    )

    return f"""Analyze the meeting notes below and produce user stories.

<meeting_notes>
{document_text}
</meeting_notes>

<existing_backlog>
{backlog_block}
</existing_backlog>

Required JSON schema:
{OUTPUT_SCHEMA_DESCRIPTION}

Here is an example of the expected quality and format (for a DIFFERENT project
-- do not copy its content, only its structure and level of detail):

{json.dumps(FEW_SHOT_EXAMPLE, indent=2)}

Now respond with the JSON object for the meeting notes above. JSON only."""
