#!/usr/bin/env python3
"""
Offline tests for the deterministic half of the pipeline.
No API key or network required. Run with:  python test_pipeline_offline.py
"""

import json

from backlog_assistant import UserStory, parse_response, render_markdown

FENCED_RESPONSE = """```json
{
  "summary": "Team needs decline reasons surfaced at checkout.",
  "open_questions": ["Does 3DS need different handling?"],
  "stories": [
    {
      "title": "Show card decline reasons at checkout",
      "story": "As a shopper, I want to see why my card was declined, so that I can fix it and complete my purchase.",
      "acceptance_criteria": ["Decline code from Stripe is mapped to friendly copy", "Each decline reason suggests a next step"],
      "priority": "P1",
      "category": "feature",
      "rationale": "Top support ticket category (~40/week).",
      "related_backlog_ids": [],
      "possible_duplicate_of": null
    }
  ]
}
```"""

MESSY_STORY = {
    "title": "Fix flaky auth test",
    "story": "As a developer, I want auth_test.py to pass reliably, so that CI failures are meaningful.",
    "acceptance_criteria": "- Test passes 50 consecutive runs\n- Root cause documented",
    "priority": "High",            # invalid -> should normalize to P2
    "category": "Testing",         # invalid -> should normalize to 'feature'
    "rationale": "Re-running hides real failures.",
}


def test_parse_strips_fences():
    result = parse_response(FENCED_RESPONSE)
    assert result["stories"][0]["priority"] == "P1"
    print("PASS  parse_response strips markdown fences")


def test_parse_with_preamble():
    raw = "Here is the JSON you asked for:\n" + FENCED_RESPONSE
    result = parse_response(raw)
    assert "summary" in result
    print("PASS  parse_response tolerates a preamble")


def test_parse_garbage_raises():
    try:
        parse_response("I could not process that document, sorry!")
    except ValueError:
        print("PASS  parse_response raises ValueError on non-JSON")
        return
    raise AssertionError("expected ValueError for garbage input")


def test_story_normalization():
    story = UserStory.from_dict(MESSY_STORY)
    assert story.priority == "P2", story.priority
    assert story.category == "feature", story.category
    assert story.acceptance_criteria == [
        "Test passes 50 consecutive runs",
        "Root cause documented",
    ], story.acceptance_criteria
    print("PASS  UserStory normalizes bad enums and string criteria")


def test_render_markdown():
    result = parse_response(FENCED_RESPONSE)
    stories = [UserStory.from_dict(d) for d in result["stories"]]
    md = render_markdown(result, stories, "notes.txt")
    assert "## Generated user stories" in md
    assert "- [ ] Decline code from Stripe" in md
    assert "Does 3DS need different handling?" in md
    print("PASS  render_markdown produces expected sections")


if __name__ == "__main__":
    test_parse_strips_fences()
    test_parse_with_preamble()
    test_parse_garbage_raises()
    test_story_normalization()
    test_render_markdown()
    print("\nAll offline pipeline tests passed.")
