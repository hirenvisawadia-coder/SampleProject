# Application Assessment Worksheet — <<APP_NAME>>

> One worksheet per application. Complete during SME walkthrough + technical probe (Playbook §3.1–§3.4).
> Replace every `<<...>>` placeholder. Attach evidence screenshots in `/evidence/<<APP_ID>>/`.

## A. Identification
| Field | Value |
|---|---|
| App ID | <<APP-01>> |
| App name | <<...>> |
| Business owner / SME | <<name, email>> |
| Assessed by / date | <<developer name>> / <<yyyy-mm-dd>> |
| App type | <<Desktop / Web / Shell-CLI / Hybrid>> |
| Tech stack & version | <<e.g., WPF .NET 4.8, Java Swing 8, Electron 28, Bash>> |
| Third-party control libraries | <<DevExpress / Telerik / Infragistics / none / unknown>> |
| Deployment model | <<Local install / Citrix-published / VDI / Browser>> |
| Authentication | <<AD SSO / MFA (type) / smartcard / local>> |
| Test environment URL/host | <<...>> |
| Environment refresh cycle & contention | <<...>> |

## B. SME Interview Summary
| Question | Answer |
|---|---|
| Release cadence & change volume | <<...>> |
| Regression suite size / manual effort per cycle | <<# cases>> / <<person-days>> |
| Existing automation (tool, coverage, health, why it failed/succeeded) | <<...>> |
| Top 5 defect-prone areas (from defect data) | 1. <<>> 2. <<>> 3. <<>> 4. <<>> 5. <<>> |
| Test data creation/refresh/masking | <<...>> |
| Upstream/downstream integrations in E2E flows | <<...>> |
| Compliance / data-residency constraints | <<can data go to Applitools cloud? Y/N/needs approval>> |

## C. Technical Probe Results (mandatory for desktop apps)
> Tools: Accessibility Insights for Windows or inspect.exe; WinAppDriver + `desktop_smoke.robot`; FlaUInspect as alternative.

| Check | Result | Evidence file |
|---|---|---|
| UIA tree exposes Name/AutomationId on key screens? | <<Full / Partial / None>> | <<screenshot.png>> |
| Top 3 complex controls & recognition result | 1. <<grid — native/partial/image-only>> 2. <<>> 3. <<>> | <<...>> |
| WinAppDriver session attaches to app? (`desktop_smoke.robot` result) | <<Pass / Fail + error>> | <<log.html>> |
| Elevated (admin) windows present? | <<Y/N — where>> | |
| Citrix/RDP layer (pixel-only)? | <<Y/N>> — if Y, Applitools/visual fallback required | |
| Embedded browser panels (CEF/WebView2)? | <<Y/N — which screens>> | |
| Native modal dialogs / file pickers? | <<Y/N>> | |
| MFA in login flow? | <<Y/N — bypass available in test env?>> | |
| Remediation levers | <<dev can inject AutomationIds? API/DB seam for setup? test-env MFA bypass?>> | |

### C.1 Shell/CLI apps only
| Check | Result |
|---|---|
| Interface contract | <<exit codes / stdout patterns / output files / DB writes>> |
| Idempotent / re-runnable? | <<Y/N — cleanup needed>> |
| Runtime per execution | <<...>> |

## D. Scoring (1–5 per dimension; see Playbook §3.2 anchors)
| Dimension | Weight | Score (1–5) | Weighted | Justification (1 line, evidence-based) |
|---|---|---|---|---|
| Object identifiability | 20% | <<>> | <<>> | <<>> |
| App & environment stability | 15% | <<>> | <<>> | <<>> |
| Test data readiness | 10% | <<>> | <<>> | <<>> |
| Change frequency vs. locator stability | 10% | <<>> | <<>> | <<>> |
| Business criticality of regression | 15% | <<>> | <<>> | <<>> |
| Manual regression effort (payoff) | 15% | <<>> | <<>> | <<>> |
| Existing automation reusability | 5% | <<>> | <<>> | <<>> |
| Workflow complexity | 10% | <<>> | <<>> | <<>> |
| **AFI (Σ weighted × 20, /100)** | | | **<<0–100>>** | **RAG: <<Green ≥70 / Amber 45–69 / Red <45>>** |

## E. Candidate Scenarios from this App
| # | Scenario (1 line) | Challenge pattern(s) | Manual effort/run | Notes |
|---|---|---|---|---|
| 1 | <<>> | <<custom grid / dynamic ID / OCR / cross-app / Citrix / none>> | <<min>> | <<>> |
| 2 | <<>> | <<>> | <<>> | <<>> |
| 3 | <<>> | <<>> | <<>> | <<>> |

## F. Risks / Blockers / Notes
- <<...>>
