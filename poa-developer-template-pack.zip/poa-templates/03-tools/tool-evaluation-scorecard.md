# Tool Evaluation Scorecard — <<Stack A>> vs <<Stack B>>

> Client baseline: **Robot Framework** as the orchestration layer. The comparison is between two
> open-source *stacks* under Robot Framework, e.g.:
> - **Stack A:** Robot Framework + AppiumLibrary + WinAppDriver (+ Applitools EyesLibrary for visual)
> - **Stack B:** Robot Framework + FlaUI Library (robotframework-flaui) (+ Applitools / image fallback)
> Adjust stack names below. Score 1–5. Paper scores in Week 2; replace with **pilot-measured** scores by Day 16.

| # | Criterion | Weight | Stack A score | Stack A evidence | Stack B score | Stack B evidence |
|---|---|---|---|---|---|---|
| 1 | Desktop technology support (client's actual stacks: <<list>>) | 20% | <<>> | <<probe results per app>> | <<>> | <<>> |
| 2 | Object recognition robustness (measured: native recognition %) | 15% | <<>> | <<pilot-metrics-log>> | <<>> | <<>> |
| 3 | AI/visual capabilities (Applitools integration, self-healing options) | 12% | <<>> | <<Eyes results, healed locators>> | <<>> | <<>> |
| 4 | Script maintainability (keyword reuse %, repair minutes after UI change) | 10% | <<>> | <<maintenance-experiment-log>> | <<>> | <<>> |
| 5 | CI/CD integration (pipeline run proof, parallel exec w/ pabot) | 8% | <<>> | <<CI run link>> | <<>> | <<>> |
| 6 | Skills availability & learning curve (client team already knows RF) | 8% | <<>> | <<>> | <<>> | <<>> |
| 7 | Licensing & 3-yr TCO (OSS = infra + Applitools tier + effort) | 8% | <<>> | <<TCO sheet>> | <<>> | <<>> |
| 8 | Cross-platform coverage (Browser/Selenium lib for web, Process lib for CLI) | 6% | <<>> | <<>> | <<>> | <<>> |
| 9 | Reporting & analytics (log.html, output.xml → dashboard/Jira) | 5% | <<>> | <<>> | <<>> | <<>> |
| 10 | Community/maintenance health of libraries (note: WinAppDriver maintenance status — verify current) | 5% | <<>> | <<repo activity check date>> | <<>> | <<>> |
| 11 | Test data & environment management fit | 3% | <<>> | <<>> | <<>> | <<>> |
| | **Weighted total (/5 → ×20 = /100)** | 100% | **<<>>** | | **<<>>** | |

## Knockout Check (fail any = eliminated; complete before scoring)
| Knockout | Stack A | Stack B |
|---|---|---|
| Recognizes dominant desktop tech (native or viable fallback)? | <<Pass/Fail>> | <<>> |
| Applitools data egress approved by client security? (else on-prem/offline visual fallback) | <<Pass/Fail/Conditional>> | <<>> |
| CI/CD path proven? | <<>> | <<>> |
| Library actively maintained / fork strategy acceptable? | <<>> | <<>> |

## Narrative (1 paragraph per stack — fill after pilot)
**Stack A — strengths / limitations observed / fit statement:** <<...>>
**Stack B — strengths / limitations observed / fit statement:** <<...>>

## Recommendation
Primary stack: <<...>> | Complementary layers: <<Browser lib for web, Process lib for shell, Requests lib for API>> | Conditions/remediations: <<...>>
