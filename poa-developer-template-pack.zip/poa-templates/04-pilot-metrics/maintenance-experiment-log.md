# Day-15 Maintenance Experiment Log

> Purpose: measure real maintenance cost per stack after a deliberate UI change (Playbook §6.2/§6.3).
> Rule: same change, both stacks, timed independently by <<developer(s)>>.

## Change Applied
| Field | Value |
|---|---|
| App / screen changed | <<>> |
| Change description | <<e.g., renamed button AutomationId 'btnSubmit'→'btnConfirm'; moved field; new column in grid>> |
| Applied by / date-time | <<>> |
| Scenarios impacted | <<SC-00x, SC-00y>> |

## Results per Stack
| Metric | Stack A | Stack B |
|---|---|---|
| Tests failing after change (#) | <<>> | <<>> |
| Failure detection clarity (was root cause obvious from log.html? 1–5) | <<>> | <<>> |
| Locator-fallback / self-healing events (auto-recovered without edit) | <<>> | <<>> |
| Applitools flagged intended visual change correctly? (Y/N/NA) | <<>> | <<>> |
| Files edited (#) — should be object-repo only if framework is clean | <<>> | <<>> |
| **Repair time to all-green (minutes)** | **<<>>** | **<<>>** |
| Notes | <<>> | <<>> |

## Failure Classification Log (append every failed run during pilot)
| Date | Scenario | Stack | Run # | Failure summary | Cause (App defect / Env / Test data / Recognition / Tool-library / Script) | Action taken | Time lost (min) |
|---|---|---|---|---|---|---|---|
| <<>> | <<>> | <<>> | <<>> | <<>> | <<>> | <<>> | <<>> |
