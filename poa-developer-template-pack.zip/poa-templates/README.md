# PoA Developer Template Pack — Robot Framework + Open-Source Stack

Companion to the 4-Week PoA Playbook. Every `<<...>>` is a placeholder for the developer to fill.

## Stack Under Evaluation
| Layer | Stack A | Stack B |
|---|---|---|
| Desktop | Robot Framework + AppiumLibrary + **WinAppDriver** | Robot Framework + **robotframework-flaui** (direct UIA) |
| Visual AI | **Applitools Eyes** (eyes-robotframework) | Applitools / offline SSIM fallback |
| Web | Browser library (Playwright) | same |
| Shell/CLI | Process + OperatingSystem libraries | same |
| Parallel/CI | pabot + Azure DevOps or Jenkins | same |

**Architect's note:** WinAppDriver has had long periods of low maintenance — verify current repo
status during Week 2 (scorecard criterion #10) and treat FlaUI as a genuine Stack B, not a formality.
Applitools requires a security gate: screenshots leave the premises (knockout check in scorecard).

## Contents
```
01-assessment/app-assessment-worksheet.md      → 1 copy per app (9 total), Week 1
02-scenarios/scenario-shortlist-register.csv   → single register, Day 6 sign-off
03-tools/tool-evaluation-scorecard.md          → paper scores Day 7, empirical Day 16
04-pilot-metrics/pilot-metrics-log.csv         → append per scenario × stack, Weeks 3–4
04-pilot-metrics/maintenance-experiment-log.md → Day 15 experiment + failure classification
framework/                                     → Robot Framework skeleton (below)
```

## Framework Setup (Day 8)
1. Windows workstation: enable **Developer Mode**; install **WinAppDriver**; run as admin:
   `WinAppDriver.exe 127.0.0.1 4723`
2. `pip install -r framework/requirements.txt` then `rfbrowser init`
3. Set environment variables (never commit): `APPLITOOLS_API_KEY`, `POA_TEST_PASSWORD`
4. Fill `framework/config/env_config.py` for the client environment.
5. Validate with the probe: `robot --variablefile config/env_config.py:UAT tests/desktop/desktop_smoke_probe.robot`
6. Pin the working library versions in `requirements.txt` and record them here: <<versions>>.

## Developer Rules (non-negotiable for fair tool comparison)
1. **No raw locators in test files** — object-repo resources only. Every locator gets a comment noting recognition method (AutomationId/Name/XPath/image) — this feeds the recognition-rate metric.
2. **Same scenario in both stacks**, same effort budget; log actual hours in the metrics CSV as you go, not from memory.
3. **4-hour blocker timebox** — then switch to fallback (XPath → image → visual assert) and record it in the failure classification log as a finding.
4. Every significant step: `Capture Step Evidence`; every test teardown: `Log Recognition Metric`.
5. Every failed run gets a cause classification (app/env/data/recognition/tool/script) — no exceptions.
6. Credentials via environment variables or vault; secrets never in git.
7. Tag every suite: `stackA|stackB`, `app-0x`, `sc-00x`, pattern tags (`pattern-grid`, `pattern-citrix`…). Tags drive selective CI runs and metric slicing.

## Running
```
# Single suite, Stack A
robot --variablefile config/env_config.py:UAT --include sc-001ANDstackA tests/

# Full Stack A in parallel
pabot --processes 2 --variablefile config/env_config.py:UAT --include stackA --outputdir results tests/

# 10x stability run (Day 15)
powershell .\utils\run_stability.ps1 -Tag stackA -Runs 10
```

## Definition of Done — per scenario, per stack
- [ ] Suite runs green 3× locally, follows template structure, only object-repo locators
- [ ] Applitools checkpoint(s) added where a visual state matters (or offline fallback + finding logged)
- [ ] Metrics row completed in `pilot-metrics-log.csv` (dev hours, recognition counts, timings)
- [ ] Evidence screenshots + `log.html` archived under `results/<scenario>/`
- [ ] At least one CI pipeline execution proven (link recorded in scorecard criterion #5)
