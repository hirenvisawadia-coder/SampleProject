# =====================================================================
# env_config.py — Global configuration (Variable file)
# Usage: robot --variablefile config/env_config.py:UAT tests/
# DO NOT hard-code credentials here. Use environment variables / vault.
# =====================================================================
import os


def get_variables(env: str = "UAT"):
    envs = {
        "UAT": {
            # ---- WinAppDriver (Stack A: AppiumLibrary + WinAppDriver) ----
            "WAD_URL": "http://127.0.0.1:4723",           # WinAppDriver default endpoint
            "APP_UNDER_TEST": r"<<C:\Path\To\App.exe or AppUserModelId for UWP>>",
            "APP_WORKING_DIR": r"<<C:\Path\To>>",
            "IMPLICIT_WAIT": "10s",

            # ---- Web (Browser / SeleniumLibrary) ----
            "WEB_BASE_URL": "<<https://uat.client-app.example>>",
            "BROWSER": "chromium",
            "HEADLESS": True,

            # ---- Shell / CLI ----
            "CLI_SCRIPTS_DIR": r"<<path to shell scripts>>",

            # ---- Applitools Eyes ----
            # Set APPLITOOLS_API_KEY as an ENVIRONMENT VARIABLE, never in git.
            "APPLITOOLS_APP_NAME": "<<Client PoA>>",
            "APPLITOOLS_BATCH_NAME": f"PoA-{env}",
            "EYES_MATCH_LEVEL": "Strict",   # Strict | Layout | Content — Layout for dynamic screens

            # ---- Test data ----
            "TEST_DATA_DIR": "data/uat",
            "DB_CONN_STRING": os.environ.get("POA_DB_CONN", "<<set via env var>>"),
        },
        # Duplicate and adjust for other environments:
        "SIT": {},
    }
    variables = envs.get(env, envs["UAT"])
    variables["ENV_NAME"] = env
    return variables
