*** Settings ***
Documentation     <<SC-00X — shell/CLI scenario>> | Script: <<script.sh>> | Author: <<dev>>
...               Contract validated: exit code + stdout pattern + output file + optional DB state.
Resource          ../../resources/cli_keywords.resource
Test Tags         cli    <<app-0x>>    <<sc-00x>>

*** Test Cases ***
SC00X - <<Script Name>> - Success Path
    ${result}=    Run Shell Script    <<script.sh>>    <<arg1>>    <<arg2>>
    Exit Code Should Be    ${result}    0
    Stdout Should Match    ${result}    <<regex e.g. Processed \\d+ records>>
    Output File Should Contain    <<path/to/output.csv>>    <<expected content>>

SC00X - <<Script Name>> - Invalid Input Handling
    ${result}=    Run Shell Script    <<script.sh>>    <<bad-arg>>
    Exit Code Should Be    ${result}    <<non-zero expected>>
    Should Contain    ${result.stderr}    <<expected error text>>
