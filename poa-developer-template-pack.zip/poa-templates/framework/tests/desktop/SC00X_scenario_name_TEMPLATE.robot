*** Settings ***
Documentation     <<SC-00X — one-line scenario description>>
...               App: <<APP-0X name>> | Type: Desktop | Challenge pattern(s): <<custom grid / dynamic ID / ...>>
...               Manual baseline: <<NN min>> | Author: <<developer>> | Traceability: <<Jira/ALM ID>>
...               STACK: A (AppiumLibrary+WinAppDriver). Copy suite and swap Resource for Stack B (FlaUI).
Resource          ../../resources/desktop_keywords.resource
Resource          ../../resources/visual_keywords.resource
Suite Setup       Launch Desktop Application
Suite Teardown    Close Desktop Application
Test Teardown     Run Keywords    Capture Step Evidence    teardown
...               AND    Log Recognition Metric    <<total>>    <<native>>    <<fallbacks>>
Test Tags         desktop    <<app-0x>>    <<sc-00x>>    <<pattern-grid>>    stackA

*** Variables ***
${TEST_USER}      <<from data file / env var — never hard-code credentials>>

*** Test Cases ***
SC00X - <<Scenario Name>> - Happy Path
    [Documentation]    Steps mirror the manual test case <<TC-ref>>.
    Given User Is Logged In    ${TEST_USER}
    When User <<performs main action>>
    Then <<expected result>> Is Displayed
    And Screen Matches Visual Baseline    <<checkpoint-name>>

SC00X - <<Scenario Name>> - <<Negative/Alternate Flow>>
    [Documentation]    <<...>>
    Fail    <<implement — remove>>

*** Keywords ***
User Is Logged In
    [Arguments]    ${user}
    Input Text By Automation Id    <<txtUsername>>    ${user}
    Input Text By Automation Id    <<txtPassword>>    %{POA_TEST_PASSWORD}
    Click Element By Automation Id    <<btnLogin>>
    Capture Step Evidence    logged_in

User <<performs main action>>
    Fail    <<implement using ONLY object-repo variables + shared keywords — remove>>

<<expected result>> Is Displayed
    Element Text Should Be    ${<<LOCATOR_VAR>>}    <<expected value>>

Screen Matches Visual Baseline
    [Arguments]    ${checkpoint}
    Open Visual Test    ${TEST NAME}
    Visual Checkpoint Window    ${checkpoint}
    Close Visual Test
