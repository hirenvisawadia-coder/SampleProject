*** Settings ***
Documentation     Assessment-week probe (Playbook §3.3): proves WinAppDriver can attach to the app
...               and recognize its key controls. Run per desktop app; paste result into the
...               app-assessment-worksheet section C. Takes <15 min per app once WAD is running.
Resource          ../../resources/desktop_keywords.resource
Suite Teardown    Close Desktop Application
Test Tags         probe

*** Test Cases ***
Probe - Session Attaches
    Launch Desktop Application    <<app path>>
    Capture Step Evidence    session_open

Probe - Key Controls Recognized
    [Documentation]    Try the 3 most complex controls identified with inspect.exe.
    ...                Record per control: native / partial / not found.
    Wait Until Element Is Visible    accessibility_id=<<control1_id>>    10s
    Wait Until Element Is Visible    accessibility_id=<<control2_id>>    10s
    Wait Until Element Is Visible    accessibility_id=<<control3_id>>    10s
    Capture Step Evidence    controls_found
