*** Settings ***
Documentation     <<SC-00X — web scenario>> | App: <<APP-0X>> | Baseline: <<NN min>> | Author: <<dev>>
Resource          ../../resources/web_keywords.resource
Resource          ../../resources/visual_keywords.resource
Suite Setup       Open Web Application
Suite Teardown    Close Web Application
Test Tags         web    <<app-0x>>    <<sc-00x>>

*** Test Cases ***
SC00X - <<Web Scenario Name>>
    Login To Web App    <<user>>    %{POA_TEST_PASSWORD}
    <<Step keyword>>
    Open Visual Test    ${TEST NAME}
    Visual Checkpoint Window    <<screen-state>>
    Close Visual Test

*** Keywords ***
<<Step keyword>>
    Fail    <<implement — remove>>
