# =====================================================================
# run_stability.ps1 — Day-15 stability experiment (Playbook §6.3)
# Runs the tagged suite N times, keeps each output, prints pass/flaky summary.
# Usage: .\utils\run_stability.ps1 -Tag stackA -Runs 10 -Env UAT
# =====================================================================
param(
    [string]$Tag = "stackA",
    [int]$Runs = 10,
    [string]$Env = "UAT"
)

$results = @()
for ($i = 1; $i -le $Runs; $i++) {
    $out = "results/stability/$Tag/run$i"
    robot --variablefile config/env_config.py:$Env --include $Tag --outputdir $out tests/
    $results += @{ Run = $i; ExitCode = $LASTEXITCODE }
    Write-Host "Run $i complete (rc=$LASTEXITCODE)"
}

$passed = ($results | Where-Object { $_.ExitCode -eq 0 }).Count
Write-Host "=================================================="
Write-Host "STABILITY SUMMARY [$Tag]: $passed / $Runs runs green"
Write-Host "Pass rate: $([math]::Round($passed / $Runs * 100, 1))%  -> record in pilot-metrics-log.csv"
Write-Host "Classify every failure in maintenance-experiment-log.md (failure classification table)."
Write-Host "Merge reports: rebot --outputdir results/stability/$Tag --merge results/stability/$Tag/run*/output.xml"
