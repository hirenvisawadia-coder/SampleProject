---
description: Scan the client's existing automation repo(s) and Jira test assets — build the brownfield inventory
argument-hint: [optional: repo name or path filter]
---

Build/refresh the brownfield inventory that grounds all later generation. Argument (optional repo/path filter): $ARGUMENTS

Prerequisites: `context/environment/environment.md` is filled in (run `/speckit.init` first if not).

## Part 1 — Azure Repos scan

1. Using the Azure DevOps MCP server, enumerate the automation repo(s) listed in the environment context (honoring $ARGUMENTS filter if given).
2. Map the repo layout: where suites, resources, variable files, Python libraries, and pipelines live.
3. Sample representative files (login/setup resources, 2–3 suites per app type, custom libraries) and infer:
   - naming styles (suites, tests, keywords, variables),
   - locator strategy (data-testid? xpath? automation IDs?),
   - tagging scheme, setup/teardown patterns, wait/retry patterns,
   - library imports and versions (check requirements.txt / conda / poetry files).
4. Build the reusable asset index: business keywords, page objects/screen maps, utility keywords — with path and one-line purpose.
5. Note anti-patterns to avoid replicating (sleeps, duplicated locators, god-keywords).
6. Write ALL of this into `context/azure-repos/conventions.md` (overwrite the placeholder table).

## Part 2 — Jira test asset scan

1. Using the Atlassian MCP server, query the client's Jira project(s) for:
   - manual test cases (per the test-management flavor recorded in environment.md),
   - recurring defect clusters (top components/labels by bug count, last 6–12 months),
   - stories with acceptance criteria patterns.
2. Write a summary to `context/jira/test-asset-inventory.md`:
   - how many manual test cases exist, per app/component,
   - which are already automated (look for links/labels like `automated`),
   - defect hotspots (candidate regression pack targets),
   - conventions for how ACs and test steps are written.

## Part 3 — Report

Present a short summary: repo conventions found, reusable assets counted, Jira inventory stats, automation coverage gaps, and recommend 2–3 high-value features/defect clusters to start with. Next step: `/speckit.specify <jira-keys>`.

Rules:
- Read-only: this command never writes to Jira or Azure Repos.
- If the repo is huge, sample intelligently rather than reading everything; record what was sampled.
