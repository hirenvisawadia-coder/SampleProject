---
description: Execute the task list — generate/extend Robot Framework code, verify, and deliver a PR
argument-hint: <feature-id>
---

Implement the tasks for: $ARGUMENTS

## Steps

1. Load `specs/$ARGUMENTS/spec.md`, `plan.md`, `tasks.md` (all Approved / present), plus `memory/constitution.md` and `context/azure-repos/conventions.md`.
2. Work through `tasks.md` in order, checking off tasks as they complete (resume from the first unchecked task if re-run):
   - follow the plan's file-touch table exactly; if reality forces a deviation, record it in plan §6 and continue,
   - generated code follows the client's conventions from `conventions.md` (naming, locator style, tagging, setup/teardown),
   - L1 tests: business-readable, Given/When/Then flow, one behavior each, tags = Jira key + level + platform + priority (Constitution Art. III.4),
   - no hardcoded URLs/credentials — variables files + env vars only,
   - every keyword gets `[Documentation]`; every suite gets suite documentation citing spec + Jira keys.
3. **Verification tasks are not optional**:
   - run `robot --dryrun` on touched suites; fix until clean,
   - if a target environment is reachable, execute the new tests; classify failures as app defect vs script defect; for suspected app defects, offer to draft a Jira bug (create only with user confirmation),
   - run the tag audit: `python scripts/audit_tags.py robot/tests` (every test must carry a Jira key tag).
4. Update `specs/$ARGUMENTS/traceability.md` from `templates/traceability-template.md` with real run results.
5. Delivery (Constitution Art. VI): commit on `feature/$ARGUMENTS` with `[<JIRA-KEY>] <summary>` messages, push, and open a PR via Azure DevOps MCP. Never push to main. Record the PR link in tasks.md Completion Record.
6. Report: tests created/extended, dry-run + run results, coverage vs ACs, PR link, and any deviations from plan.

## Hard rules
- Do not invent locators/element IDs — if one is unknown, stop the relevant task and ask.
- Do not mark a task done if its verification failed.
- Writes to Jira (comments, links, bugs) and PR creation always get explicit user confirmation first.
