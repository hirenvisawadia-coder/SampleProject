---
description: One-time client onboarding — capture environment context and customize the constitution
---

You are onboarding this spec-driven test automation kit for a new client engagement.

Steps:

1. Read `memory/constitution.md` and `context/environment/environment.md`.
2. Verify tool access:
   - Try a lightweight Atlassian MCP call (e.g., list Jira projects). If unavailable, tell the user to configure `.mcp.json` (see `docs/mcp-setup.md`) and stop.
   - Try a lightweight Azure DevOps MCP call (e.g., list repos). Same fallback.
3. Interview the user to fill every `[BRACKETED]` placeholder in `context/environment/environment.md`:
   - client name, Jira site + project keys, test-management flavor (Xray/Zephyr/plain),
   - Azure Repos org/project/repo(s) that hold existing automation,
   - the applications under test: for each, type (web/desktop/shell), tech stack, access details, and the Robot Framework library to use (Constitution Art. IV),
   - environments, credentials strategy, test data strategy.
   Ask in small batches (AskUserQuestion when available); write answers into the file as you go.
4. Update `memory/constitution.md`: resolve its `[BRACKETED]` choices (web library, desktop library, reporting target, architect name). Record the edit in `memory/constitution-changelog.md`.
5. Confirm Jira conventions by sampling real issues: fetch 2–3 stories, 2–3 defects, and 2–3 test cases from the client's Jira project; record where acceptance criteria live and how tests are linked, in `context/environment/environment.md` → "Jira Conventions".
6. Summarize what was captured and tell the user the next step is `/speckit.discover`.

Rules:
- Never invent client facts — every value comes from the user or from live Jira/Azure queries.
- Do not proceed past step 2 if MCP connectivity is broken.
