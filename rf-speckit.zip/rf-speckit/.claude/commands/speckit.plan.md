---
description: Turn an approved spec into a technical implementation plan (HOW, in Robot Framework terms)
argument-hint: <feature-id e.g. 005-claim-submission>
---

Create the implementation plan for spec: $ARGUMENTS

## Steps

1. Load `specs/$ARGUMENTS/spec.md` — verify Status is **Approved**; if not, stop and say so.
2. Load `memory/constitution.md`, `context/environment/environment.md`, `context/azure-repos/conventions.md`.
3. **Re-verify reuse targets**: for each REUSE/EXTEND asset in spec §3.2, fetch the current file from Azure Repos (MCP) and confirm the keyword/locator still exists and its signature. Update decisions if the repo moved on.
4. For the app type(s), design per Constitution Art. III & IV:
   - **Web**: page-object resources; selector strategy consistent with `conventions.md`; explicit waits.
   - **Desktop**: screen-map resources; automation IDs / control paths (ask user to run FlaUInspect/inspect.exe and paste control trees if unknown — do NOT guess element identifiers).
   - **Shell**: command inventory; expected exit codes/output patterns; SSH vs local Process.
5. Write `specs/$ARGUMENTS/plan.md` from `templates/plan-template.md`:
   - complete file-touch table (REUSE/EXTEND/CREATE),
   - L2 keyword designs with argument lists,
   - scenario→test mapping with exact test names and tags (Jira key + level + platform + priority),
   - test data plan and execution plan,
   - constitution check with any violations flagged.
6. Present a compact summary (files to touch, new keywords, risks) and STOP for human approval (Constitution Art. VI). Next: `/speckit.tasks $ARGUMENTS`.

## Quality gates
- [ ] Every spec scenario appears in the scenario→test mapping
- [ ] Every CREATE decision justified (why no reuse)
- [ ] Element identifiers are sourced (repo, user-provided inspect output) — never invented
- [ ] Naming matches `conventions.md`, not generic defaults
