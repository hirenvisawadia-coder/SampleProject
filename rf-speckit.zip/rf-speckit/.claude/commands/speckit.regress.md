---
description: Fast path — generate a regression test directly from a Jira defect
argument-hint: <defect-key e.g. PROJ-401>
---

Create a defect-driven regression test for: $ARGUMENTS

This is the lightweight loop for single defects (full features go through /speckit.specify → plan → tasks → implement).

## Steps

1. Fetch the defect from Jira (Atlassian MCP): description, steps to reproduce, environment, comments, linked story, resolution notes.
2. Search existing automation for a test already covering this path; if one exists, propose extending it instead and stop for user choice.
3. Write a **mini-spec** `specs/defects/$ARGUMENTS.md`: repro steps → Given/When/Then scenario(s) (happy path guard + the exact failure path), trace to the defect key. Show it and get a quick user OK.
4. Generate the test into the matching existing suite (or a `regression/` suite per conventions), tags: `<defect-key>  regression  <platform>  <priority>`.
5. Verify: `robot --dryrun`; execute against the environment if reachable — on a fixed build the test should PASS; on an unfixed build it should FAIL at the defect step (state which situation applies).
6. Offer to: link the automation to the defect in Jira (comment with test name + repo path) and open a PR. Both need user confirmation.

Rules: same hard rules as /speckit.implement (no invented locators, no unverified done, confirmations for writes).
