---
description: Audit generated (or existing) suites against the constitution and traceability
argument-hint: [feature-id | path under robot/tests | blank for whole repo]
---

Review scope: $ARGUMENTS (default: entire `robot/` tree + all specs)

## Checks

1. **Constitution compliance** (`memory/constitution.md`):
   - layering: no locators in test files; L2 keywords compose L3; tests business-readable,
   - tagging: every test has Jira key + level + platform + priority (run `python scripts/audit_tags.py`),
   - independence: no test depends on another's side effects; setup/teardown present,
   - no hardcoded secrets/URLs (grep for http(s)://, password-like strings in suites).
2. **Traceability**: every spec scenario has a test; every test traces to a spec scenario or defect; flag orphans both ways. Cross-check `specs/*/traceability.md`.
3. **Convention drift**: compare naming/locator/tag style against `context/azure-repos/conventions.md`.
4. **Robot health**: `robot --dryrun` across scope; `robocop` lint if installed (`pip show robotframework-robocop`).
5. **Staleness**: for each spec's Jira keys, check (Atlassian MCP) whether the story/defect changed after the spec's date — flag specs needing refresh.

## Output

A findings report ordered by severity (violation → warning → info), each with file:line and a concrete fix. Offer to auto-fix mechanical items (tags, documentation, naming) as a follow-up.
