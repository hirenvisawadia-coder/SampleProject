---
description: Create a test specification from Jira stories/defects/test cases (WHAT to verify, no implementation)
argument-hint: <jira-keys e.g. PROJ-123 PROJ-401> [free-text scope notes]
---

Create a test specification for: $ARGUMENTS

Prerequisites: constitution customized, `context/` populated by `/speckit.init` + `/speckit.discover`.

## Steps

1. Load `memory/constitution.md`, `context/environment/environment.md`, `context/azure-repos/conventions.md`, `context/jira/test-asset-inventory.md`.
2. **Fetch the Jira artifacts** (Atlassian MCP) for every key in $ARGUMENTS, plus:
   - linked issues (blocks/relates/tests links),
   - linked or component-matching defects (these seed negative/regression scenarios),
   - existing manual test cases covering the same story/component,
   - relevant comments that clarify acceptance criteria.
3. **Search existing automation** (Azure DevOps MCP + the asset index in conventions.md) for anything already covering these flows. Record REUSE / EXTEND / CREATE decisions with justification (Constitution Art. II).
4. Determine the next spec ID: highest number in `specs/` + 1, short kebab name (e.g. `005-claim-submission`). Create `specs/<feature-id>/`.
5. Write `specs/<feature-id>/spec.md` from `templates/spec-template.md`:
   - map EVERY acceptance criterion to ≥1 scenario,
   - derive negative/edge scenarios from linked defects and boundary analysis,
   - convert referenced manual test cases into scenarios (keep the Jira key trace),
   - business language ONLY — no locators, keywords, or tool syntax,
   - anything ambiguous goes into §9 Open Questions marked [NEEDS CLARIFICATION].
6. If §9 has open questions, ask the user now (AskUserQuestion when available) and fold answers back into the spec.
7. Print the AC→scenario coverage table and STOP: ask the human to review/approve the spec (Constitution Art. VI). Next step after approval: `/speckit.plan <feature-id>`.

## Quality gates (self-check before presenting)
- [ ] Every AC mapped; every linked defect either covered by a scenario or explicitly out-of-scope
- [ ] Every scenario has Given/When/Then with an assertable Then
- [ ] Zero implementation details in the spec
- [ ] Source Analysis section cites real Jira keys and real repo paths (verified, not guessed)
