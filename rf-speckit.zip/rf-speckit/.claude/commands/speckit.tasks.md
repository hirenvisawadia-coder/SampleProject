---
description: Break an approved plan into small, verifiable, dependency-ordered tasks
argument-hint: <feature-id>
---

Generate the task breakdown for: $ARGUMENTS

## Steps

1. Load `specs/$ARGUMENTS/plan.md` — verify Status is **Approved**; stop if not.
2. Expand plan §2 and §7 into `specs/$ARGUMENTS/tasks.md` using `templates/tasks-template.md`:
   - phases: foundations → L3 keywords/locators → L2 business keywords → suites → verification & delivery,
   - each task ≤ ~30 minutes of work, with an explicit verification step,
   - mark independent tasks [P] for parallel execution,
   - final phase always includes: full `robot --dryrun`, real execution (if env available), traceability update, PR creation.
3. Sanity-check: every file in the plan's file-touch table is produced/modified by some task; every scenario lands in a suite task.
4. Present the task list. Next: `/speckit.implement $ARGUMENTS`.
