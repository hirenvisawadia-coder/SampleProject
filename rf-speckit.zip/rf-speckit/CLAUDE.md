# RF-SpecKit — Spec-Driven Robot Framework Test Automation

You are the automation engineer for this repository. It generates Robot Framework test automation for **brownfield** applications (web, desktop, shell) from client context in **Jira** (stories, defects, test cases) and **Azure Repos** (existing automation code).

## Non-negotiables
1. Read `memory/constitution.md` before any spec/plan/code work — it governs everything.
2. Workflow order is fixed: `/speckit.init` → `/speckit.discover` → `/speckit.specify` → `/speckit.plan` → `/speckit.tasks` → `/speckit.implement` (plus `/speckit.regress` fast path and `/speckit.review` audit). Never skip the human approval gates after specify and plan.
3. Brownfield first: search existing assets (Azure Repos + `context/azure-repos/conventions.md`) before creating anything. Reuse > Extend > Create.
4. Never invent Jira content, repo paths, locators, or element IDs. Fetch real data via MCP or ask the user.
5. All writes to Jira and Azure DevOps (comments, bugs, PRs) require explicit user confirmation. Never push to main.

## Repository map
| Path | Purpose |
|---|---|
| `memory/constitution.md` | governing principles (customized per client) |
| `context/` | client environment, Jira inventory, repo conventions — living documents |
| `templates/` | spec / plan / tasks / traceability templates |
| `specs/<feature-id>/` | one folder per feature: spec.md, plan.md, tasks.md, traceability.md |
| `specs/defects/` | mini-specs from /speckit.regress |
| `robot/` | Robot Framework project (tests, resources, variables) |
| `scripts/` | audit_tags.py and helper scripts |
| `pipelines/` | Azure DevOps pipeline templates |
| `docs/` | setup + onboarding guides |

## Robot Framework conventions (defaults — client conventions in `context/azure-repos/conventions.md` override these)
- Layering: tests (L1) → business keywords (L2, `robot/resources/<platform>/flows/`) → technical keywords/page objects (L3, `robot/resources/<platform>/`).
- Tags on every test: Jira key, level (`smoke|regression|e2e`), platform (`web|desktop|shell`), priority (`P1|P2|P3`).
- Variables per environment in `robot/variables/<env>.py`; secrets via `%{ENV_VAR}` only.
- `robot --dryrun` must pass before any commit.

## Tooling
- Jira: Atlassian MCP server (`.mcp.json`) — stories, defects, test cases, links.
- Azure Repos: Azure DevOps MCP server — repo browse/read, PR creation.
- If an MCP server is down, say so and point to `docs/mcp-setup.md`; do not scrape or guess.
