# RF-SpecKit — Spec-Driven Test Automation for Brownfield Apps

A portable, spec-driven development kit that turns a client's existing context —
**Jira** user stories, defects, and manual test cases, plus **existing automation
code in Azure Repos** — into maintainable **Robot Framework** test automation for
web, Windows desktop, and shell/batch applications.

Drop this repo into any client engagement, run the onboarding command, and the AI
agent (Claude Code) generates automation that follows the client's own conventions,
with full Jira traceability and human approval gates.

## Why spec-driven?

Brownfield automation fails when scripts are generated straight from prompts: no
traceability, duplicated keywords, ignored conventions. This kit forces the flow
**intent → spec → plan → tasks → code**, with the client's real artifacts as input
and human review between each stage.

```
 Jira stories/defects/test cases ──┐
                                   ├─▶ /speckit.specify ─▶ spec.md   (WHAT, approved by human)
 Azure Repos existing automation ──┘          │
                                              ▼
                                   /speckit.plan ────▶ plan.md      (HOW, approved by human)
                                              ▼
                                   /speckit.tasks ───▶ tasks.md     (small verifiable steps)
                                              ▼
                                   /speckit.implement ▶ Robot code + traceability + PR
```

## Quick start (per client)

1. **Prereqs**: Claude Code, Python 3.10+, `pip install -r requirements.txt`
   (then `rfbrowser init` if using Browser Library).
2. **Connect**: configure Jira + Azure DevOps MCP servers — `docs/mcp-setup.md`.
3. **Onboard**: run `/speckit.init` — interviews you to capture the client's
   environment context and customize the constitution.
4. **Discover**: run `/speckit.discover` — scans the client's automation repo(s)
   and Jira test assets; writes the brownfield inventory the generator must respect.
5. **Generate**: per feature, `/speckit.specify PROJ-123 PROJ-124` → review →
   `/speckit.plan <id>` → review → `/speckit.tasks <id>` → `/speckit.implement <id>`.
6. **Fast path**: single defect? `/speckit.regress PROJ-401`.
7. **Audit**: `/speckit.review` any time.

## Commands

| Command | Purpose |
|---|---|
| `/speckit.init` | one-time client onboarding: context capture + constitution customization |
| `/speckit.discover` | scan Azure Repos + Jira; build brownfield inventory & conventions |
| `/speckit.specify <jira-keys>` | Jira artifacts → reviewed test specification (WHAT) |
| `/speckit.plan <feature-id>` | approved spec → technical RF plan (HOW) |
| `/speckit.tasks <feature-id>` | approved plan → dependency-ordered task list |
| `/speckit.implement <feature-id>` | tasks → Robot code, verification, traceability, PR |
| `/speckit.regress <defect-key>` | fast defect → regression test loop |
| `/speckit.review [scope]` | constitution/traceability/convention audit |

## Repository layout

```
memory/constitution.md      governing principles (customized per client)
context/                    client environment, Jira inventory, repo conventions
templates/                  spec / plan / tasks / traceability templates
specs/<feature-id>/         one folder per generated feature
robot/                      Robot Framework project (L1 tests / L2 flows / L3 page-screen maps)
scripts/audit_tags.py       machine-checkable tagging compliance
pipelines/                  Azure DevOps pipeline template
docs/                       setup and platform guides
.claude/commands/           the /speckit.* command pack
CLAUDE.md                   agent operating instructions
```

## Platform support

| Platform | Default library | Notes |
|---|---|---|
| Web | Browser (Playwright) or SeleniumLibrary | choice recorded per client during init |
| Windows desktop | FlaUILibrary (UIA3) | needs interactive Windows runner — `docs/desktop-runner.md` |
| Shell / batch | SSHLibrary + Process | exit codes, output patterns, produced files |

## Guardrails baked in

- Reuse > Extend > Create — existing client keywords are inventoried and preferred.
- No invented locators, Jira content, or repo paths — live MCP data or ask.
- Human approval gates after spec and plan; PRs only, never direct pushes to main.
- Every test tagged with Jira key + level + platform + priority (enforced by `scripts/audit_tags.py`).
- Secrets via env vars / Key Vault only.

## Adapting per client

Everything client-specific lives in exactly three places: `memory/constitution.md`
(the bracketed choices), `context/**` (living context files), and
`robot/variables/*.py` (environment config). The commands, templates, and skeleton
stay untouched between engagements — that's what makes the kit portable.
