# Existing Automation Conventions (discovered)

<!--
Written by /speckit.discover after scanning the client's automation repo(s) in Azure Repos.
Generated code MUST follow these conventions (Constitution Art. II.3).
-->

| Aspect | Client convention | Example (path) |
|---|---|---|
| Directory layout | | |
| Suite naming | | |
| Test naming style | | |
| Keyword naming style | | |
| Locator strategy | | |
| Variable files | | |
| Tagging scheme | | |
| Setup/Teardown pattern | | |
| Library imports | | |
| Custom Python libraries | | |

## Reusable asset index
<!-- High-value existing keywords/resources the generator should prefer. -->
| Asset | Path | What it does |
|---|---|---|

## Anti-patterns observed (do not replicate)
- [e.g., sleeps instead of waits — new code uses explicit waits even though legacy code sleeps]
