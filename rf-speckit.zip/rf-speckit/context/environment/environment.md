# Client Environment Context

<!--
Filled in during /speckit.init and kept current. This is the single source of truth
about the client's landscape. The agent loads this before every /speckit command.
-->

## Client & Engagement
| Field | Value |
|---|---|
| Client | [name] |
| Engagement owner | [architect] |
| Automation repo(s) in Azure Repos | [org/project/repo, branch] |
| Jira site & projects | [https://client.atlassian.net — PROJ, QA] |
| Test management in Jira | [Xray / Zephyr Scale / TestRail link / plain issues] |

## Applications Under Test
| App | Type | Tech stack | Access (URL/host/exe) | RF library choice | Notes |
|---|---|---|---|---|---|
| Claims Portal | web | Angular 12 | https://qa.claims.client.com | Browser Library | SSO via test IdP |
| Policy Admin | desktop | WPF (.NET 4.8) | C:\Apps\PolicyAdmin.exe | FlaUILibrary | runs on VM WIN-QA-02 |
| Nightly batch | shell | ksh on AIX | ssh batchqa@10.x.x.x | SSHLibrary | exit codes + log files |

## Environments
| Env | Purpose | Data refresh | Who can break it |
|---|---|---|---|
| DEV | | | |
| QA | primary automation target | | |
| UAT | | | |

## Credentials & Secrets Strategy
- Mechanism: [env vars / Azure Key Vault / CyberArk / .env not committed]
- Test users & roles: [list or vault path]

## Test Data Strategy
- Creation: [API seeding / DB scripts / UI setup / static fixtures]
- Isolation & cleanup rules:

## Jira Conventions
- Story issue type(s): [Story, Feature]  ·  Defect type(s): [Bug]
- Test case representation: [Xray Test issue type / linked pages]
- Acceptance criteria location: [description "AC:" section / custom field cf[10021]]
- Linking conventions: [tests linked via "tests" link type]

## Azure Repos Conventions
- Automation repo layout summary: [paths to suites/resources/libs]
- Branching: [feature/* → PR → main, build validation pipeline]
- PR reviewers for automation: [names/groups]

## Known Constraints / Gotchas
- [e.g., desktop VM needs interactive session for FlaUI; grid IDs are dynamic; batch window 02:00–04:00]
