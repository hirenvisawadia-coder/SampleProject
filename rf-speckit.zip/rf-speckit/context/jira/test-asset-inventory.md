# Jira Test Asset Inventory (discovered)

<!-- Written by /speckit.discover Part 2. Placeholder until the first discovery run. -->

## Manual test cases
| App / component | Count | Already automated | Notes |
|---|---|---|---|

## Defect hotspots (last 6–12 months)
| Component / label | Bug count | Candidate regression pack? |
|---|---|---|

## Story & AC conventions observed
- Acceptance criteria location:
- Test step format:
- Linking conventions:
