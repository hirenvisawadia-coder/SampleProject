# Client Onboarding Checklist

Work through this on day one of an engagement. Target: first generated test within a day.

## Access
- [ ] Jira: account (or service account) with read access to the target project(s); write access decided (defect drafting on/off)
- [ ] Azure DevOps: PAT or `az login` for the org; Code (Read) minimum, PR (Read & Write) if the agent opens PRs
- [ ] Target environment reachable from the machine running the agent (VPN, allowlists)
- [ ] Test user credentials placed in env vars / vault (never in the repo)
- [ ] Desktop apps only: Windows VM per `docs/desktop-runner.md`

## Kit setup
- [ ] Clone this kit into the engagement workspace (fresh copy per client)
- [ ] `pip install -r requirements.txt` (+ `rfbrowser init` for Browser library)
- [ ] Create `.mcp.json` from `docs/mcp-setup.md`; verify both connectors respond
- [ ] Run `/speckit.init` — completes environment.md + constitution customization
- [ ] Run `/speckit.discover` — conventions.md + Jira inventory populated

## First feature (proving loop)
- [ ] Pick one high-value story or defect cluster from the discover report
- [ ] `/speckit.specify <keys>` → review the spec WITH the client's QA lead
- [ ] `/speckit.plan <id>` → confirm reuse decisions against their repo
- [ ] `/speckit.tasks <id>` → `/speckit.implement <id>`
- [ ] Dry run green, real run triaged, PR opened into their automation repo
- [ ] Walk the client through spec → traceability.md → PR as the repeatable loop

## Governance agreed with client
- [ ] Who approves specs and plans (names)
- [ ] Defect-drafting policy (agent proposes Jira bugs: yes/no)
- [ ] Result reporting target (Xray / Zephyr / Azure Test Plans / none)
- [ ] Branch/PR policy for the automation repo
