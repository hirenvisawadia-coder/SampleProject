# Windows Desktop Test Runner Setup (FlaUI)

UI Automation (UIA3) needs a real, unlocked, interactive Windows session — a locked
screen or a plain service-mode CI agent will make FlaUI keywords fail or flake.

## Runner requirements
- Windows 10/11 or Server VM with the app under test installed.
- Azure DevOps self-hosted agent running **interactively** (not as a service):
  configure autologon for the agent account and run `run.cmd` at logon.
- Keep the session unlocked: disable lock policy on the VM, or use `tscon` redirect
  when disconnecting RDP:
  `tscon %sessionname% /dest:console`
- Screen resolution fixed (e.g. 1920×1080) — control coordinates and image-based
  fallbacks depend on it.

## Capturing element identifiers
Never guess AutomationIds. Capture them with:
- **FlaUInspect** (https://github.com/FlaUI/FlaUInspect) — shows the UIA3 tree,
  or **Accessibility Insights for Windows** / Windows SDK `inspect.exe`.
- Paste the relevant control tree into the conversation when `/speckit.plan` asks;
  the plan records the XPath for each element in the L3 screen map.

## Legacy apps with no automation support
If the app exposes no UIA tree (very old Win32, Java AWT, Citrix-published):
- try SikuliLibrary (image recognition) as the L3 layer — same L1/L2 structure applies,
- record the choice and its fragility in `context/environment/environment.md`.

## Pipeline wiring
Enable the commented `Execute_Desktop` stage in `pipelines/azure-pipelines.yml` and
point it at the Windows interactive agent pool. Desktop suites are tagged `desktop`
so Linux stages exclude them with `--exclude desktop`.
