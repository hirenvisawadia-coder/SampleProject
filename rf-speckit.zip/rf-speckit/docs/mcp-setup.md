# MCP Connector Setup (Jira + Azure Repos)

The kit's commands query Jira and Azure Repos live through MCP servers. Configure them
once per client machine, then verify via `/speckit.init`.

## 1. Create `.mcp.json` at the repo root

Copy this into a file named `.mcp.json` (it is gitignored by default — check with the
client's security team before committing any connector config):

```json
{
  "mcpServers": {
    "atlassian": {
      "type": "sse",
      "url": "https://mcp.atlassian.com/v1/sse"
    },
    "azure-devops": {
      "command": "npx",
      "args": ["-y", "@azure-devops/mcp", "your-org-name"]
    }
  }
}
```

## 2. Atlassian (Jira) MCP

- The official Atlassian remote MCP server uses OAuth: the first Jira call opens a
  browser login against the client's Atlassian site. The logged-in user's Jira
  permissions apply — request a service/test account with read access to the
  relevant projects (and write access only if defect-drafting is wanted).
- Self-hosted alternative (Jira Data Center or locked-down Cloud): use a community
  Jira MCP server with a PAT, e.g. `mcp-atlassian` (Docker), with env vars
  `JIRA_URL`, `JIRA_USERNAME`, `JIRA_API_TOKEN` supplied from the client's vault.
- Verify: ask Claude to "list Jira projects" — you should see the client's project keys.

## 3. Azure DevOps MCP

- Official server: `@azure-devops/mcp` (`npx -y @azure-devops/mcp <org>`). It
  authenticates via Azure CLI (`az login`) or `AZURE_DEVOPS_EXT_PAT`.
- Minimum PAT scopes: **Code (Read)** for discovery/generation; add **Code (Read & Write)**
  + **Pull Request (Read & Write)** if the agent should push branches and open PRs.
- Verify: ask Claude to "list repositories in project X".

## 4. Locked-down environments (no MCP allowed)

Fallback: export context manually and drop it into the `context/` folders —
- Jira: filter export (CSV/XML) of stories, defects, and test cases → `context/jira/exports/`
- Azure Repos: `git clone` the automation repo(s) next to this kit and point
  `/speckit.discover` at the local clone path.
The commands work with either live MCP or these local exports; they always say which
source they used.

## 5. Security notes

- Never commit PATs or API tokens. `.gitignore` covers `.env` and `.mcp.json`.
- Prefer read-only credentials until the team is comfortable with the PR flow.
- All agent writes (Jira comments/bugs, PRs) require human confirmation by
  constitution — connectors alone don't grant the agent autonomy.
