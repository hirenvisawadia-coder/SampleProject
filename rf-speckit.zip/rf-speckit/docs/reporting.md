# Result Reporting Back to Jira / Azure DevOps

Choose ONE per client during `/speckit.init` and record it in
`context/environment/environment.md`.

## Option A — Jira Xray
- Robot's `output.xml` imports natively: `POST /api/v2/import/execution/robot`
  (Xray Cloud) with the project key and test plan key.
- Tag ↔ Xray mapping: the Jira key tag on each test (e.g. `PROJ-123`) lets Xray
  auto-link results to Test issues.
- Pipeline: add a step after execution:
  `curl -H "Authorization: Bearer $XRAY_TOKEN" --data-binary @robot/results/output.xml "$XRAY_URL/import/execution/robot?projectKey=PROJ"`

## Option B — Zephyr Scale
- Use the Zephyr Scale REST API `POST /automations/executions/custom` with a
  translated JUnit file (`robot --xunit xunit.xml` produces it).

## Option C — Azure Test Plans
- Publish via the pipeline's `PublishTestResults@2` task (already wired in
  `pipelines/azure-pipelines.yml` using the xunit output); associate automated
  tests to test cases in Azure Test Plans if the client uses them.

## Option D — None (reports as artifacts)
- The pipeline publishes `log.html` / `report.html` as build artifacts; the
  traceability matrix in each spec folder remains the source of truth.

In every option, `robot` should run with `--xunit xunit.xml` so JUnit-consuming
tools work without extra conversion (the provided pipeline does this — keep the
flag if you customize).
