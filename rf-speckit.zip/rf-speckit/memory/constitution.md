# Test Automation Constitution

<!--
This constitution governs every spec, plan, and script generated in this repository.
The AI agent MUST read this file before executing any /speckit command.
Customize the [BRACKETED] items per client engagement during /speckit.init.
-->

## Article I — Spec Before Script

1. No Robot Framework code is generated without an approved spec in `specs/<feature-id>/spec.md`.
2. Every spec MUST trace back to at least one source-of-truth artifact:
   - a Jira user story / feature (issue key recorded in the spec header),
   - a Jira defect (for regression tests),
   - or an existing manual test case in Jira (Xray/Zephyr/TestRail-in-Jira).
3. A spec describes **WHAT** to verify and **WHY** (business intent, acceptance criteria, risk). It never contains locators, keywords, or tool syntax.

## Article II — Brownfield First

1. Before writing anything new, the agent MUST search existing assets:
   - existing Robot suites/resources in the Azure Repos automation repo(s),
   - shared keyword libraries and page objects,
   - existing manual test cases in Jira.
2. **Reuse > Extend > Create.** New keywords are created only when no existing keyword can be reused or reasonably extended. Every new keyword's spec entry records why reuse was not possible.
3. Naming, layout, and style of generated code MUST match the conventions discovered in the client's existing automation repo (recorded in `context/azure-repos/conventions.md`), not the defaults in this kit — the kit's defaults apply only when the client has no existing conventions.

## Article III — Robot Framework Standards

1. All automated tests are Robot Framework (`.robot` / `.resource`); Python libraries only as thin adapters where RF libraries are insufficient.
2. Test cases live in `robot/tests/`, keywords in `robot/resources/`, and data in `robot/variables/` — tests contain NO raw locators or credentials.
3. Layered keyword architecture:
   - **L1 Test cases** — business-readable, Given/When/Then style, one behavior per test.
   - **L2 Business/flow keywords** — reusable flows ("Login As Standard User", "Submit Claim").
   - **L3 Technical keywords / page objects / screen maps** — locators, selectors, element IDs.
4. Every test MUST be tagged with, at minimum: Jira issue key (e.g. `PROJ-123`), test level (`smoke`/`regression`/`e2e`), app type (`web`/`desktop`/`shell`), and priority.
5. Tests MUST be independent, re-runnable, and clean up their own data unless the spec explicitly documents an exception.
6. Secrets come from environment variables or a vault integration — never committed.

## Article IV — Platform Adapters

1. **Web**: [Browser Library (Playwright) | SeleniumLibrary] — pick per client, record choice in `context/environment/environment.md`.
2. **Desktop (Windows)**: [FlaUILibrary | SikuliLibrary | image-based fallback] for WinForms/WPF/legacy apps.
3. **Shell/CLI/batch**: SSHLibrary for remote hosts, Process library for local execution; assertions on exit codes, stdout/stderr, and produced files.
4. One suite may exercise multiple platforms, but each keyword belongs to exactly one platform resource layer.

## Article V — Traceability & Reporting

1. Spec ⇄ Jira ⇄ script traceability is mandatory and machine-checkable: Jira keys appear in spec headers, test tags, and commit messages.
2. Generated tests report results back to [Jira Xray / Zephyr / Azure Test Plans / none] via the CI pipeline (configure in `pipelines/`).
3. Every generation run produces/updates `specs/<feature-id>/traceability.md` mapping: story → acceptance criterion → spec scenario → robot test → last run status.

## Article VI — Human Gates

1. A human reviews and approves: (a) the spec, (b) the plan, before code generation proceeds. The agent MUST stop and ask at these gates.
2. Generated code is delivered on a feature branch with a pull request into the client's automation repo — never pushed to main.
3. `robot --dryrun` MUST pass before a PR is opened; a real execution against the target environment is required before merge where an environment is available.

## Article VII — Client Context Is King

1. The agent MUST load `context/environment/environment.md` (URLs, credentials handling, app inventory, test data strategy) before planning.
2. When client context is missing or ambiguous, the agent asks targeted questions and records answers back into the context files — context files are living documents.
3. Nothing environment-specific is hardcoded in tests; it flows through `robot/variables/` per-environment files (`dev.py`, `qa.py`, `uat.py`).

---
**Amendment process**: changes to this constitution require agreement from the automation architect ([NAME]) and are recorded in `memory/constitution-changelog.md`.
