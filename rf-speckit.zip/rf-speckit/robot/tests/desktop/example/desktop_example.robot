*** Settings ***
Documentation     EXAMPLE L1 suite for Windows desktop testing style (FlaUI).
...               Spec: specs/000-example/spec.md  ·  Jira: DEMO-3
...               NOTE: runs only on a Windows host with an interactive session —
...               see docs/desktop-runner.md. Excluded from Linux CI via the
...               `desktop` tag (pipelines use --exclude desktop off-Windows).
Resource          ../../../resources/desktop/main_window.resource
Suite Setup       Load Environment Config    DESKTOP_APP_PATH    DESKTOP_APP_WINDOW_TITLE
Test Setup        Launch Application Under Test
Test Teardown     Close Application Under Test

*** Test Cases ***
Application Starts And Shows Ready Status
    [Documentation]    Trace: DEMO-3 / AC-1 / S-01
    [Tags]    DEMO-3    smoke    desktop    P1
    Then Status Bar Should Show    Ready

File Menu Is Accessible
    [Documentation]    Trace: DEMO-3 / AC-2 / S-02
    [Tags]    DEMO-3    regression    desktop    P2
    When Open File Menu
    Then Status Bar Should Show    Ready
