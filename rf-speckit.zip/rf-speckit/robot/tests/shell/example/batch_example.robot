*** Settings ***
Documentation     EXAMPLE L1 suite for shell/batch testing style.
...               Spec: specs/000-example/spec.md  ·  Jira: DEMO-2
Resource          ../../../resources/shell/batch_host.resource
Suite Setup       Run Keywords    Load Environment Config    BATCH_HOST    BATCH_USER    SSH_KEY_PATH
...               AND    Connect To Batch Host
Suite Teardown    Disconnect From Batch Host

*** Test Cases ***
Nightly Extract Job Completes Successfully
    [Documentation]    Trace: DEMO-2 / AC-1 / S-01 — job exits 0 and writes a dated log.
    [Tags]    DEMO-2    regression    shell    P1
    ${stdout}=    Run Remote Command And Expect Success    /opt/batch/run_extract.sh --env qa
    Should Contain    ${stdout}    EXTRACT COMPLETE
    Remote File Should Contain    /var/log/batch/extract_qa.log    rc=0

Extract Job Rejects Unknown Environment
    [Documentation]    Trace: DEMO-2 / AC-2 / S-02 — negative path from defect DEMO-401.
    [Tags]    DEMO-2    DEMO-401    regression    shell    P2
    ${stdout}    ${stderr}    ${rc}=    Execute Command    /opt/batch/run_extract.sh --env bogus
    ...    return_stderr=True    return_rc=True
    Should Be Equal As Integers    ${rc}    2
    Should Contain    ${stderr}    Unknown environment
