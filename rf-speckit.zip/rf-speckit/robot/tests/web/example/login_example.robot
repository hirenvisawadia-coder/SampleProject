*** Settings ***
Documentation     EXAMPLE L1 suite showing the required style for generated web tests.
...               Spec: specs/000-example/spec.md  ·  Jira: DEMO-1
...               Business-readable, one behavior per test, no locators, full tagging.
...               Robot strips Given/When/Then prefixes automatically when matching keywords.
Resource          ../../../resources/web/flows/authentication.resource
Suite Setup       Load Environment Config    APP_BASE_URL    HEADLESS
Test Teardown     Run Keyword And Ignore Error    Close Browser    ALL

*** Test Cases ***
Valid User Can Log In
    [Documentation]    Trace: DEMO-1 / AC-1 / S-01
    [Tags]    DEMO-1    smoke    web    P1
    When Login As    STANDARD
    Then Get Url    contains    dashboard

Invalid Password Is Rejected With Error Message
    [Documentation]    Trace: DEMO-1 / AC-2 / S-02
    [Tags]    DEMO-1    regression    web    P2
    ${username}=    Get Secret    TEST_USER_STANDARD
    When Attempt Login With Invalid Password    ${username}
    Then Login Error Should Be Visible    Invalid username or password
