"""Per-environment variables — QA. Copy to dev.py / uat.py and adjust.

Only non-secret configuration lives here. Secrets are read at runtime from
environment variables via the `Get Secret` keyword (common.resource):
    TEST_USER_<ROLE>, TEST_PASS_<ROLE>, BATCH_HOST_PASSWORD, ...
"""

# --- Web ---
APP_BASE_URL = "https://qa.example-client.com"
HEADLESS = True

# --- Desktop (Windows runner) ---
DESKTOP_APP_PATH = r"C:\\Apps\\ExampleApp\\ExampleApp.exe"
DESKTOP_APP_WINDOW_TITLE = "Example App"

# --- Shell / batch ---
BATCH_HOST = "batch-qa.example-client.com"
BATCH_USER = "batchqa"
SSH_KEY_PATH = "~/.ssh/batch_qa_ed25519"
