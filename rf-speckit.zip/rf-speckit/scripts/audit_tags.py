#!/usr/bin/env python3
"""Audit Robot Framework test tags against the constitution (Art. III.4).

Every test must carry:
  - a Jira issue key tag (e.g. PROJ-123)
  - a level tag: smoke | regression | e2e
  - a platform tag: web | desktop | shell
  - a priority tag: P1 | P2 | P3

Usage: python scripts/audit_tags.py [path (default: robot/tests)] [--jira-prefix PROJ]
Exit code 0 = compliant, 1 = violations found.
"""
import argparse
import re
import sys
from pathlib import Path

try:
    from robot.api import TestSuiteBuilder
except ImportError:
    sys.exit("robotframework is not installed: pip install robotframework")

LEVELS = {"smoke", "regression", "e2e"}
PLATFORMS = {"web", "desktop", "shell"}
PRIORITIES = {"p1", "p2", "p3"}


def iter_tests(suite):
    yield from suite.tests
    for child in suite.suites:
        yield from iter_tests(child)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("path", nargs="?", default="robot/tests")
    ap.add_argument("--jira-prefix", default=None,
                    help="Require Jira keys to start with this project prefix")
    args = ap.parse_args()

    root = Path(args.path)
    if not root.exists():
        sys.exit(f"Path not found: {root}")

    jira_re = re.compile(
        rf"^{re.escape(args.jira_prefix)}-\d+$" if args.jira_prefix else r"^[A-Z][A-Z0-9]+-\d+$"
    )

    suite = TestSuiteBuilder().build(str(root))
    violations = []
    total = 0
    for test in iter_tests(suite):
        total += 1
        tags = [str(t) for t in test.tags]
        lower = {t.lower() for t in tags}
        problems = []
        if not any(jira_re.match(t) for t in tags):
            problems.append("missing Jira key tag")
        if not lower & LEVELS:
            problems.append(f"missing level tag ({'/'.join(sorted(LEVELS))})")
        if not lower & PLATFORMS:
            problems.append(f"missing platform tag ({'/'.join(sorted(PLATFORMS))})")
        if not lower & PRIORITIES:
            problems.append("missing priority tag (P1/P2/P3)")
        if problems:
            violations.append((test.source, test.name, problems))

    if violations:
        print(f"TAG AUDIT: {len(violations)}/{total} tests non-compliant\n")
        for source, name, problems in violations:
            print(f"  {source} :: {name}")
            for p in problems:
                print(f"      - {p}")
        sys.exit(1)
    print(f"TAG AUDIT: all {total} tests compliant")


if __name__ == "__main__":
    main()
