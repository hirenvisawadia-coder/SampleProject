# Implementation Plan: [FEATURE NAME]

| Field | Value |
|---|---|
| Spec | specs/[feature-id]/spec.md (Status MUST be Approved) |
| Status | Draft \| In Review \| Approved |
| Platform(s) | [web / desktop / shell] |
| RF libraries | [Browser / SeleniumLibrary / FlaUILibrary / SSHLibrary / Process / …] |
| Target repo/branch | [Azure Repos repo] / feature/[feature-id] |

## 1. Constitution Check
<!-- Confirm each relevant constitution article is satisfied; flag violations for human decision. -->
- [ ] Art. I — spec approved, traceable to Jira keys: …
- [ ] Art. II — existing-asset search completed (queries + results summarized): …
- [ ] Art. III — layered keyword design below conforms
- [ ] Art. VII — environment context loaded from `context/environment/environment.md`

## 2. Architecture of the Change

### 2.1 Files to touch
| Action | File | Purpose |
|---|---|---|
| REUSE | robot/resources/web/login.resource | unchanged |
| EXTEND | robot/resources/web/claims_page.resource | + `Fill Adjuster Notes` locator/keyword |
| CREATE | robot/tests/web/claims/claim_submission.robot | scenarios S-01..S-06 |
| CREATE | robot/variables/qa.py | + CLAIMS_URL |

### 2.2 Keyword design (L2 business keywords)
<!-- For each new/extended keyword: name, arguments, return, which L3 keywords it composes. -->
| Keyword | Args | Composes | Notes |
|---|---|---|---|

### 2.3 Locator / element strategy (L3)
<!-- Web: selector strategy & stability notes. Desktop: automation IDs / control trees from inspect.exe or FlaUInspect. Shell: commands, expected exit codes, output patterns. -->

## 3. Scenario → Test mapping
| Scenario | Robot test name | Suite file | Tags |
|---|---|---|---|
| S-01 | Valid Claim Is Submitted Successfully | claim_submission.robot | PROJ-123  smoke  web  P1 |

## 4. Test Data Plan
<!-- How each data item from spec §7 is created/loaded/cleaned: fixtures, API setup calls, DB seeds, suite Setup/Teardown. -->

## 5. Execution Plan
- Local run command: `robot --variablefile robot/variables/qa.py --include PROJ-123 robot/tests/...`
- Dry run gate: `robot --dryrun …` must pass
- CI: pipeline stage in `pipelines/azure-pipelines.yml`, results published to [Xray/Zephyr/Azure Test Plans]

## 6. Risks & Mitigations
| Risk | Mitigation |
|---|---|
| flaky locator on legacy grid | explicit waits + retry keyword `Wait Until Grid Loaded` |

## 7. Estimated Task Breakdown Preview
<!-- High-level; /speckit.tasks expands this into tasks.md -->
1. Extend page object …
2. Author suite …
3. Wire test data …
4. Dry run + real run + PR

## 8. Review & Approval
- [ ] Reuse decisions match spec §3.2
- [ ] No credentials/URLs hardcoded
- [ ] Approved by: __________  Date: ______
