# Test Specification: [FEATURE NAME]

| Field | Value |
|---|---|
| Spec ID | [feature-id, e.g. 004-claim-submission] |
| Status | Draft \| In Review \| Approved |
| Author | [agent + human reviewer] |
| Date | [YYYY-MM-DD] |
| App under test | [app name] ([web / desktop / shell]) |
| Jira stories | [PROJ-123, PROJ-124] |
| Jira defects covered | [PROJ-401 …] |
| Existing Jira test cases referenced | [PROJ-T-55 …] |
| Existing automation reused | [paths in Azure Repos, or "none found — searched <queries>"] |

## 1. Business Intent
<!-- WHY this feature/flow matters, in the customer's words. Summarize from the Jira story description. -->

## 2. Scope

### In scope
- [flows / screens / commands under test]

### Out of scope
- [explicitly excluded, with reason]

## 3. Source Analysis (brownfield inventory)

### 3.1 From Jira
| Artifact | Key | Summary | Relevance |
|---|---|---|---|
| Story | PROJ-123 | … | acceptance criteria below |
| Defect | PROJ-401 | … | regression scenario S-05 |
| Manual test case | PROJ-T-55 | … | converted to S-01..S-03 |

### 3.2 From Azure Repos (existing automation)
| Asset | Path | Reuse decision |
|---|---|---|
| `login.resource` | tests/resources/web/login.resource | REUSE as-is |
| `claims_page.resource` | … | EXTEND: add locator for new field |
| — | — | CREATE: no keyword exists for X because … |

## 4. Acceptance Criteria → Test Scenarios

<!-- One row per acceptance criterion from the Jira story. Every criterion MUST map to ≥1 scenario. -->

| AC # | Acceptance criterion (from Jira) | Scenario ID(s) |
|---|---|---|
| AC-1 | … | S-01, S-02 |

## 5. Test Scenarios

<!-- Business language only. NO locators, NO keyword names, NO tool syntax. -->

### S-01: [scenario title]  `[smoke|regression|e2e]` `[P1|P2|P3]`
- **Given** [precondition, incl. test data state]
- **When** [action]
- **Then** [observable, assertable outcome]
- **Trace**: PROJ-123 / AC-1

### S-02: …

## 6. Negative & Edge Scenarios
<!-- Derived from defects, boundary analysis, and story "won't do" notes. -->

### S-NN: …

## 7. Test Data Requirements
| Data item | Source / creation strategy | Cleanup |
|---|---|---|

## 8. Environment & Preconditions
- Target environment(s): [from context/environment/environment.md]
- Required access / users / roles:
- External systems mocked or live:

## 9. Open Questions [NEEDS CLARIFICATION]
<!-- The agent lists anything ambiguous here and STOPS for human answers before the spec can be Approved. -->
- [ ] …

## 10. Review & Approval
- [ ] All acceptance criteria mapped to scenarios
- [ ] Defect-driven regression scenarios included
- [ ] Existing assets inventoried; reuse decisions justified
- [ ] No implementation details (locators/keywords) present
- [ ] Approved by: __________  Date: ______
