# Task Breakdown: [FEATURE NAME]

| Field | Value |
|---|---|
| Plan | specs/[feature-id]/plan.md (Status MUST be Approved) |
| Branch | feature/[feature-id] |

<!--
Rules:
- Tasks are small (≤ ~30 min of agent work), verifiable, and ordered by dependency.
- [P] marks tasks that can run in parallel.
- Every task lists its verification step — a task without verification is not done.
- The agent updates checkboxes as it works; humans can re-run /speckit.implement to resume.
-->

## Phase A — Foundations
- [ ] T-01 Create branch `feature/[feature-id]` from [main]  ·  verify: branch exists
- [ ] T-02 [P] Add/extend variables in `robot/variables/[env].py`  ·  verify: python imports cleanly

## Phase B — L3 technical keywords / locators
- [ ] T-03 [P] Extend `[page/screen map].resource` with locators for [elements]  ·  verify: `robot --dryrun` passes
- [ ] T-04 [P] …

## Phase C — L2 business keywords
- [ ] T-05 Implement `[Business Keyword]` composing [T-03 keywords]  ·  verify: dry run + keyword documentation present

## Phase D — Test suites
- [ ] T-06 Author `[suite].robot` implementing S-01..S-NN with tags per plan §3  ·  verify: dry run; tag audit script passes
- [ ] T-07 Suite setup/teardown wired to test-data plan  ·  verify: repeated local run is idempotent

## Phase E — Verification & delivery
- [ ] T-08 `robot --dryrun` on full suite  ·  verify: 0 errors
- [ ] T-09 Execute against [env]; triage failures (app defect vs script defect)  ·  verify: report attached to spec folder
- [ ] T-10 Update `specs/[feature-id]/traceability.md`  ·  verify: every AC row has a test + status
- [ ] T-11 Commit with message `[PROJ-123] <summary>`; open PR to [repo]  ·  verify: PR link recorded below

## Completion Record
| Item | Value |
|---|---|
| Final run report | |
| PR | |
| Jira issues updated/linked | |
