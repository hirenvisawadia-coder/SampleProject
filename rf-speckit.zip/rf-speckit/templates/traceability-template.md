# Traceability Matrix: [FEATURE NAME]

Generated/updated by `/speckit.implement` — do not edit test/status columns by hand.

| Jira story | AC | Spec scenario | Robot test | Suite file | Tags | Last run | Status |
|---|---|---|---|---|---|---|---|
| PROJ-123 | AC-1 | S-01 | Valid Claim Is Submitted Successfully | robot/tests/web/claims/claim_submission.robot | PROJ-123 smoke web P1 | [date] | PASS |

## Defect coverage
| Jira defect | Regression scenario | Robot test | Status |
|---|---|---|---|

## Coverage gaps
<!-- ACs or defects with no automated test, and why. -->
