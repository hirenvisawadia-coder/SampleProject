# Spec-Driven Desktop Test Automation POC
### Robot Framework + WinAppDriver + Windows Calculator

A proof of concept showing how to drive desktop UI test automation from
human-readable specifications, with full traceability from acceptance
criterion to test result.

## How it works

- **Specs** (`specs/*.md`) define intent and acceptance criteria in
  Gherkin. Every criterion has a stable tag like `SPEC-CALC-001-AC1`.
- **Test suites** (`tests/*.robot`) contain one test case per criterion,
  written with the *same* Given/When/Then lines as the spec and tagged
  with the criterion's tag.
- **Step definitions** (`resources/steps/*.resource`) implement each
  Gherkin phrase as a Robot Framework keyword. Robot strips the
  Given/When/Then prefix automatically — no glue code needed.
- **Locators** (`resources/common/locators.resource`) isolate all UI
  Automation IDs in one file.
- **WinAppDriver** receives the commands via **AppiumLibrary** and
  drives the real Windows Calculator UI.

See `docs/spec_driven_workflow.md` for the full workflow and rules.

## Project layout

```
sdd-robot-winappdriver-poc/
├── specs/                          # Source of truth (markdown + Gherkin)
│   ├── SPEC-CALC-001_basic_arithmetic.md
│   └── SPEC-CALC-002_display_and_clear.md
├── tests/                          # Executable Robot suites (1 test = 1 AC)
│   ├── calc_basic_arithmetic.robot
│   └── calc_display_and_clear.robot
├── resources/
│   ├── steps/calculator_steps.resource    # Gherkin step keywords
│   └── common/
│       ├── locators.resource              # All Automation IDs
│       └── variables.resource             # Endpoint, app id, timeouts
├── scripts/
│   ├── setup.ps1                   # One-time environment setup
│   └── run_tests.ps1               # Start WinAppDriver + run suites
├── docs/spec_driven_workflow.md    # The SDD process this POC follows
├── results/                        # Robot output (gitignored)
└── requirements.txt
```

## Prerequisites (Windows machine)

1. Windows 10/11 with **Developer Mode** enabled
2. **Python 3.9+** on PATH
3. **WinAppDriver 1.2.x** — `scripts/setup.ps1` installs both of the above
   prerequisites' dependencies automatically

## Quick start

```powershell
# from an elevated PowerShell prompt, in the project root:
.\scripts\setup.ps1        # one time: dev mode + WinAppDriver + venv

.\scripts\run_tests.ps1                  # run all suites
.\scripts\run_tests.ps1 SPEC-CALC-001    # run one spec
```

Or manually:

```powershell
# terminal 1
& "C:\Program Files (x86)\Windows Application Driver\WinAppDriver.exe"

# terminal 2
.\.venv\Scripts\Activate.ps1
robot --outputdir results tests
```

Open `results/report.html` — the **Statistics by Tag** table is your
spec-to-result traceability matrix.

## Validating without a Windows machine

The suites parse and all keywords resolve without touching a UI:

```bash
robot --dryrun --outputdir results tests
```

(Dry run verifies structure/keywords only; real execution needs Windows.)

## Adapting to your own application

1. Change `${CALCULATOR_APP_ID}` in `resources/common/variables.resource`
   to your app — a UWP app id, or the full path to a Win32 `.exe`.
2. Replace the Automation IDs in `resources/common/locators.resource`
   (find them with *Inspect.exe* from the Windows SDK or Accessibility
   Insights for Windows).
3. Write your first spec in `specs/`, then follow the checklist in
   `docs/spec_driven_workflow.md`.

## Notes & gotchas

- WinAppDriver speaks the *legacy* Appium protocol; `requirements.txt`
  pins `Appium-Python-Client<3.0` and `selenium<4.10` for compatibility.
- WinAppDriver must run as the logged-in desktop user (not as a service)
  and the session cannot be driven over a locked screen; for CI use an
  autologon interactive agent.
- The UWP Calculator display exposes text as `Display is <value>`; the
  `the display should show` keyword strips that prefix.
