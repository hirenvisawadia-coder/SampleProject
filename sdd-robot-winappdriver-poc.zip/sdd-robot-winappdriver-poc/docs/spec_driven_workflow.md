# Spec-Driven Development Workflow

This POC demonstrates a lightweight spec-driven development (SDD) loop
for desktop UI automation. The spec is the source of truth; tests are a
direct, traceable expression of it.

## The loop

```
 1. WRITE SPEC          specs/SPEC-XXX.md
    - intent, preconditions, acceptance criteria in Gherkin
    - every criterion gets a stable tag (SPEC-XXX-ACn)
          |
          v
 2. EXPRESS AS TESTS    tests/xxx.robot
    - one test case per acceptance criterion
    - test steps are the SAME Given/When/Then lines from the spec
    - [Tags] carry the criterion tag for traceability
          |
          v
 3. IMPLEMENT STEPS     resources/steps/*.resource
    - each Gherkin phrase becomes a Robot keyword
    - keywords talk to the app via AppiumLibrary -> WinAppDriver
    - locators live in resources/common/locators.resource only
          |
          v
 4. RUN & TRACE         scripts/run_tests.ps1
    - robot --include SPEC-XXX* runs exactly one spec
    - report.html groups results by tag = per-criterion status
          |
          v
 5. EVOLVE              spec changes first, tests follow
    - a failing test after a spec change is the signal to update
      step implementations, never the other way round
```

## Rules of the road

1. **Spec first.** No test case exists without an acceptance criterion,
   and no acceptance criterion is left without a test case.
2. **One tag per criterion.** `SPEC-CALC-001-AC3` appears in exactly one
   place in the spec and exactly one `[Tags]` entry in the suites.
3. **Specs use business language.** The words in the Gherkin lines are
   the words in the `.robot` files — copy-paste, not translation.
4. **Locators are quarantined.** UI details (Automation IDs) live only
   in `locators.resource`, so a UI change never touches a spec or test.
5. **Steps are app-facing, not test-facing.** Step keywords may compose
   each other (e.g. `the user calculates` reuses
   `the user enters the number`), keeping the vocabulary small.

## Traceability queries

| Question                              | Command                                          |
|---------------------------------------|--------------------------------------------------|
| Status of spec SPEC-CALC-001?         | `robot --include SPEC-CALC-001* tests`           |
| Status of a single criterion?         | `robot --include SPEC-CALC-001-AC2 tests`        |
| Smoke set across all specs?           | `robot --include smoke tests`                    |
| Which tests cover which criteria?     | open `results/report.html` → "Statistics by Tag" |

## Adding a new spec (checklist)

- [ ] Create `specs/SPEC-XXX_<slug>.md` with tagged acceptance criteria
- [ ] Create `tests/<slug>.robot`; one test per criterion, same Gherkin lines
- [ ] Add any new step phrases to `resources/steps/`
- [ ] Add any new locators to `resources/common/locators.resource`
- [ ] `robot --dryrun tests` passes (all keywords resolve)
- [ ] `robot --include SPEC-XXX* tests` passes against the app
