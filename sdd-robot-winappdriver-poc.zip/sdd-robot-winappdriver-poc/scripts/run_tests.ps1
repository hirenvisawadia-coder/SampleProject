# ---------------------------------------------------------------------------
# Executes the POC test suites.
#   .\scripts\run_tests.ps1                 -> run everything
#   .\scripts\run_tests.ps1 SPEC-CALC-001   -> run one spec by tag prefix
# ---------------------------------------------------------------------------
param(
    [string]$SpecTag = ""
)

$ErrorActionPreference = "Stop"
$projectRoot = Split-Path $PSScriptRoot -Parent
Set-Location $projectRoot

# 1. Start WinAppDriver if it is not already running
$wad = Get-Process "WinAppDriver" -ErrorAction SilentlyContinue
if (-not $wad) {
    Write-Host "Starting WinAppDriver..." -ForegroundColor Cyan
    Start-Process "C:\Program Files (x86)\Windows Application Driver\WinAppDriver.exe" `
        -WindowStyle Minimized
    Start-Sleep -Seconds 2
    $startedWad = $true
}

# 2. Build the robot command
$robotArgs = @(
    "--outputdir", "results",
    "--timestampoutputs"
)
if ($SpecTag) {
    $robotArgs += @("--include", "$SpecTag*")
}
$robotArgs += "tests"

# 3. Run
& .\.venv\Scripts\robot.exe @robotArgs
$exitCode = $LASTEXITCODE

# 4. Stop WinAppDriver if this script started it
if ($startedWad) {
    Stop-Process -Name "WinAppDriver" -ErrorAction SilentlyContinue
}

Write-Host "`nReports written to $projectRoot\results" -ForegroundColor Green
exit $exitCode
