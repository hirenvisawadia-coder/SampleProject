# ---------------------------------------------------------------------------
# One-time environment setup for the Robot Framework + WinAppDriver POC.
# Run from an elevated PowerShell prompt in the project root.
# ---------------------------------------------------------------------------

# 1. Enable Windows Developer Mode (required by WinAppDriver)
Write-Host "Enabling Developer Mode..." -ForegroundColor Cyan
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\AppModelUnlock" `
    /t REG_DWORD /f /v "AllowDevelopmentWithoutDevLicense" /d "1" | Out-Null

# 2. Download & install WinAppDriver if it is not already present
$wadPath = "C:\Program Files (x86)\Windows Application Driver\WinAppDriver.exe"
if (-not (Test-Path $wadPath)) {
    Write-Host "Downloading WinAppDriver 1.2.1..." -ForegroundColor Cyan
    $msi = "$env:TEMP\WindowsApplicationDriver.msi"
    Invoke-WebRequest `
        -Uri "https://github.com/microsoft/WinAppDriver/releases/download/v1.2.1/WindowsApplicationDriver_1.2.1.msi" `
        -OutFile $msi
    Start-Process msiexec.exe -ArgumentList "/i `"$msi`" /qn" -Wait
} else {
    Write-Host "WinAppDriver already installed." -ForegroundColor Green
}

# 3. Create a Python virtual environment and install dependencies
Write-Host "Setting up Python environment..." -ForegroundColor Cyan
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements.txt

Write-Host "`nSetup complete." -ForegroundColor Green
Write-Host "Next: run scripts\run_tests.ps1 to execute the POC suites."
