# SPEC-CALC-001 — Basic Arithmetic Operations

| Field          | Value                                      |
|----------------|--------------------------------------------|
| Spec ID        | SPEC-CALC-001                              |
| Title          | Basic arithmetic operations                |
| Owner          | QA Automation                              |
| Status         | Approved                                   |
| Target App     | Windows Calculator (Standard mode)         |
| Test Suite     | `tests/calc_basic_arithmetic.robot`        |

## 1. Intent

As a Calculator user, I want to perform the four basic arithmetic
operations so that I can rely on the application for everyday math.

## 2. Preconditions

- Windows 10/11 machine with WinAppDriver 1.2.x installed and running
  (default endpoint `http://127.0.0.1:4723`).
- Windows Calculator (UWP) installed
  (`Microsoft.WindowsCalculator_8wekyb3d8bbwe!App`).
- Calculator is switched to **Standard** mode before each scenario.

## 3. Acceptance Criteria

Each criterion below maps 1:1 to a tagged scenario in the test suite.

### AC-1 Addition (tag: `SPEC-CALC-001-AC1`)
```gherkin
Given the calculator is open in Standard mode
When the user calculates "5" "plus" "7"
Then the display should show "12"
```

### AC-2 Subtraction (tag: `SPEC-CALC-001-AC2`)
```gherkin
Given the calculator is open in Standard mode
When the user calculates "20" "minus" "8"
Then the display should show "12"
```

### AC-3 Multiplication (tag: `SPEC-CALC-001-AC3`)
```gherkin
Given the calculator is open in Standard mode
When the user calculates "6" "times" "7"
Then the display should show "42"
```

### AC-4 Division (tag: `SPEC-CALC-001-AC4`)
```gherkin
Given the calculator is open in Standard mode
When the user calculates "84" "divided by" "2"
Then the display should show "42"
```

## 4. Out of Scope

- Scientific / Programmer modes.
- Memory functions (see SPEC-CALC-002).
- Keyboard input (POC uses UI element clicks only).

## 5. Traceability

Run `robot --include SPEC-CALC-001* tests/` to execute exactly the
scenarios covering this spec. The generated `report.html` groups results
by tag, giving per-criterion pass/fail traceability.
