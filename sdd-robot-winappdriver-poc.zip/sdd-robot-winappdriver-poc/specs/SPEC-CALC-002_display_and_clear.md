# SPEC-CALC-002 — Display Behaviour & Clearing

| Field          | Value                                      |
|----------------|--------------------------------------------|
| Spec ID        | SPEC-CALC-002                              |
| Title          | Display behaviour and clear functions      |
| Owner          | QA Automation                              |
| Status         | Approved                                   |
| Target App     | Windows Calculator (Standard mode)         |
| Test Suite     | `tests/calc_display_and_clear.robot`       |

## 1. Intent

As a Calculator user, I want the display to reflect my input accurately
and to be able to clear it, so that I can recover from mistakes without
restarting the app.

## 2. Preconditions

Same environment as SPEC-CALC-001.

## 3. Acceptance Criteria

### AC-1 Digit entry echoes to display (tag: `SPEC-CALC-002-AC1`)
```gherkin
Given the calculator is open in Standard mode
When the user enters the number "123"
Then the display should show "123"
```

### AC-2 Clear resets the display (tag: `SPEC-CALC-002-AC2`)
```gherkin
Given the calculator is open in Standard mode
When the user enters the number "999"
And the user presses clear
Then the display should show "0"
```

### AC-3 Chained operations keep running total (tag: `SPEC-CALC-002-AC3`)
```gherkin
Given the calculator is open in Standard mode
When the user calculates "2" "plus" "3"
And the user continues with "times" "4"
Then the display should show "20"
```

## 4. Out of Scope

- Clipboard copy/paste of results.
- History / memory panes.

## 5. Traceability

Run `robot --include SPEC-CALC-002* tests/`.
