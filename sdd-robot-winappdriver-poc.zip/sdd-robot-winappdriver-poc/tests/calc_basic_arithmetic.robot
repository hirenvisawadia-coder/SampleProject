*** Settings ***
Documentation     SPEC-CALC-001 — Basic Arithmetic Operations.
...
...               Each test case implements one acceptance criterion from
...               specs/SPEC-CALC-001_basic_arithmetic.md and carries the
...               matching traceability tag.
Resource          ../resources/steps/calculator_steps.resource
Suite Setup       Open Calculator Session
Suite Teardown    Close Calculator Session
Test Setup        Reset Calculator
Test Tags         SPEC-CALC-001    smoke

*** Test Cases ***
Addition Of Two Numbers
    [Documentation]    AC-1: 5 + 7 = 12
    [Tags]    SPEC-CALC-001-AC1
    Given the calculator is open in Standard mode
    When the user calculates    5    plus    7
    Then the display should show    12

Subtraction Of Two Numbers
    [Documentation]    AC-2: 20 - 8 = 12
    [Tags]    SPEC-CALC-001-AC2
    Given the calculator is open in Standard mode
    When the user calculates    20    minus    8
    Then the display should show    12

Multiplication Of Two Numbers
    [Documentation]    AC-3: 6 * 7 = 42
    [Tags]    SPEC-CALC-001-AC3
    Given the calculator is open in Standard mode
    When the user calculates    6    times    7
    Then the display should show    42

Division Of Two Numbers
    [Documentation]    AC-4: 84 / 2 = 42
    [Tags]    SPEC-CALC-001-AC4
    Given the calculator is open in Standard mode
    When the user calculates    84    divided by    2
    Then the display should show    42
