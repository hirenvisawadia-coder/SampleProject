*** Settings ***
Documentation     SPEC-CALC-002 — Display Behaviour & Clearing.
...
...               Each test case implements one acceptance criterion from
...               specs/SPEC-CALC-002_display_and_clear.md and carries the
...               matching traceability tag.
Resource          ../resources/steps/calculator_steps.resource
Suite Setup       Open Calculator Session
Suite Teardown    Close Calculator Session
Test Setup        Reset Calculator
Test Tags         SPEC-CALC-002    regression

*** Test Cases ***
Digit Entry Echoes To Display
    [Documentation]    AC-1: typing 123 shows 123
    [Tags]    SPEC-CALC-002-AC1
    Given the calculator is open in Standard mode
    When the user enters the number    123
    Then the display should show    123

Clear Resets The Display
    [Documentation]    AC-2: clear after 999 shows 0
    [Tags]    SPEC-CALC-002-AC2
    Given the calculator is open in Standard mode
    When the user enters the number    999
    And the user presses clear
    Then the display should show    0

Chained Operations Keep Running Total
    [Documentation]    AC-3: (2 + 3) * 4 = 20
    [Tags]    SPEC-CALC-002-AC3
    Given the calculator is open in Standard mode
    When the user calculates    2    plus    3
    And the user continues with    times    4
    Then the display should show    20
